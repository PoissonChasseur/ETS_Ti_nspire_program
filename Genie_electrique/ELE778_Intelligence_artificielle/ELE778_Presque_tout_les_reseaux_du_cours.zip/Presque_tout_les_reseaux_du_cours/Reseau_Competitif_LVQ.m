%% Reseau Competitif avec Apprentissage Learning Vector Quantization (LVQ)
%{ 
Cours: ELE778
R�seau de neurone comp�titif avec Apprentissage Learning Vector Quantization (LVQ)

Note importante: Apprentissage Supervis�

Par: Vincent Rougeau-Moss (�t� 2017)

Description:
    La LVQ est une m�thode de classification de formes.
    Chaque sortie repr�sente une classe ou cat�gorie.
    Plusieurs unit�s de sortie peuvent repr�senter la m�me classe.
    Les poids des unit�s de la couche de sortie sont g�n�ralement appel�s
    prototype, r�f�rence ou m�me � codebook �. 
    L�apprentissage est supervis�.
    Durant le processus d�apprentissage, les unit�s de sortie sont
    positionn�s (en ajustant leur poids). 
    Apr�s l�apprentissage, la LVQ classifie un vecteur d�entr�e en lui
    assignant la classe dont il est le plus proche (selon une  m�trique
    donn�e). 

Particularit�:
    Une des caract�ristiques/particularit�s de cette m�thode est que plus
    on a de r�f�rences/repr�senant et plus les performances sont
    meilleures. 
   
    Compromis � faire.

Initialisation:
    1. Une fa�on simple d�initialiser la LVQ (les poids) est de prendre les
    m premiers vecteurs d�entr�e et de les utiliser comme des vecteurs
    poids. 

    2. Choisir les poids al�atoirement, mais cette m�thode est beaucoup
    moins r�pondue. 

    3. Utiliser l�algorithme des k-moyennes.

Architecture:
    L�architecture de la LVQ est similaire � celle de Kohonen; il
    y a cependant deux principales diff�rences :
        - La LVQ n�a pas une structure topologique.
        - Chaque unit� de sortie appartient � une classe bien d�termin�e.

Notation:
    - unit� couche sortie = prototype = r�f�rence = repr�sentant =
      = � codebook �.

    - X = vecteur d'entrainement [moi: vecteur d'entr�e]

    - T = classe du vecteur d'entr�e

    - w(j) = vecteur poids de l'unit� de sortie "j" 
    [(moi) = les valeurs du repr�setant - et le repr�sentant fait partie
    des donn�es comme X (labo 3). Rappel SOM: poids = position dans
    l'espace, tout comme c'est aussi le cas pour les valeurs de X].

    - C(j) = Classe de l'unit� de sortie (du repr�sentant) j. Pour labo 3,
    on a class� les noms des fichiers selon le no associ� pour aid� � faire
    �a. 
 
    - dist(x, w(j)) = distance Eucl�dienne entre X et W(j) - X et le
    repr�sentant "j". Comme avec SOM, on peut exclure la racine carr�
    puisqu'on ne fait que compar� des distances.

Algorithme:
    (0) Initialisation des poids et taux d'apprentissage initial (voir
    section plus haut sur l'initialisation - � l'examen = d�j� fait).

    Tant que le crit�re d'arr�t est invalide.
        Pour chaque vecteur d'entr�e X
            [moi] Trouv� le repr�sentant J � distance minimal de l'entr�e.
                Dist(j) = dist(x, w(j))

            Actualiser w(J) //[moi] actualiser le repr�sentant � dist. min
            de l'entr�e (seulement, sous la forme original du LVQ)
                Si T = C(J) //Si X et le repr�sentant sont de la m�me
                classe [moi].
                    w[new](J) = w[old](J) + taux_apprentissage*(x-w[old](J))

                Sinon //Repr�sentant et X pas de la m�me classe =
                �loigne le repr�sentant [moi].
                    w[new](J) = w[old](J) - taux_apprentissage*(x-w[old](J))
                    
        R�duire le taux d'apprentissage
        
        Test du crit�re d'arr�t:
            a) Nombre max d'it�ration atteint.
            b) Taux d'apprentissage minimale atteint.

Note pour programme sur Ti nspire cx cas (cas algo complet):
    Ce algorithme ne se programme pas facilement sur la Ti � cause du
    probl�me des classes et du fait qu'il est plus rapide de le faire � la
    main.

    L'id�al serait d'avoir un tableau 3D pour la Ti ou une liste de liste
    de classe o� la liste de classe contient les tableaux des repr�sentant.

    N'ayant pas �a, on aurait besoin de d�finir une grosse matrice o� on
    devrait rentrer tout les repr�sentants (au du moins ceux importants) +
    d�fininir des r�gles pour savoir diff�rencier les repr�sentant d'une
    m�me classe + les diff�rentes classes.

    Ce serait donc compliqu� � g�rer avec l'utilisateur qui peut se tromp�
    � l'examen.

Note pour programme sur Ti nspire cx cas (cas repr�senter par l'exercice en
classe);
    Dans un cas tr�s simplifi� comme l'exercice en classe o� on a toujours
    1 repr�sentant de chaque classe au maximum, � ce moment l� on peut
    avoir en param�tre seulement les 4 repr�sentant autour, ce qui permet
    une utilisation tr�s facile et simple. Cependant, c'est un cas isol�,
    mais si on a ce cas simplifi� en examen, alors c'est tr�s pratique.
    Apr�s r�flexion lors d�v�loppement sur Ti, je me suis rendu compte que
    faire �a �quivaut � faire l'algo Kohonen, mais au d�tail pr�s que
    l'actualisation du meilleur repr�sentant chaque l�g�rement selon la
    classe de l'entr�e et la classe du gagnant.

    Si c'est pas le cas, il faut juste �tre apte � le faire � la main. Pour
    �a une fonction "dist(x,y)" � �t� faite dans la Ti pour pouvoir
    rapidement calcul� la distance entre 2 vecteurs.

Note pour Ti:
    Apr�s avoir fait l'algo, oui peut se faire, mais est surement le plus
    long � faire parmi tout ceux fait jusqu'� maintenant (� cause des
    classes). M�me probl�me qu'on rencontre avec algo des K moyennes.

Note de d�v�loppement:
    Test� et semble bien fonctionner, par contre difficile de savoir si le
    fait bien d� � erreur de calcul (ex. changement des donn�es du probl�me
    ou erreur de calcul ou mauvaise transcription dans cahier de note)
    lorsqu'on a fait le no en classe.
    
    � �t� tr�s utile pour compar� performance r�seau du labo 3 avec lui
    afin de d�tecter des erreurs dans le labo 3 ou code Matlab, sachant que
    leurs m�thodes est diff�rente et data de cr�ation diff�rente (labo 3
    avec celui-ci). Une fosi petite erreur identifier dans labo 3, les deux
    avaient exactement les m�mes r�sultats, confirmeant ainsi que les deux
    sont valides (puisque m�thode de calcul et approche d'ex�cution tr�s
    diff�rente).

Source:
    - Document de cours: Chapitre 4, "Compet-12 july.pdf" (p.15 �  20/33)
%}
clear;
clc;

%------------------------------------
%DONN�ES INITIALES

%Les vecteurx d'entr�ex -> chaque ligne = 1 vecteur d'entr�e.
x = [0.25,0.25; 0.4,0.35; 0.4,0.45];
classe_x = [1; 1; 1]; %les no des classes de chaque entr�e

disp('Entr�e = x = ');
disp(x);
disp('Classe of X are ');
disp(classe_x);

%Les repr�sentants de chaque classes:
%Chaque ligne = 1 repr�sentant de la classe.
%Nb colonnes doit �tre constant et pareille aux vecteurs d'entr�es.
C1 = [0.2,0.2; 0.2,0.6; 0.6,0.4; 0.6,0.8];
C2 = [0.4,0.2; 0.4,0.6; 0.8,0.4; 0.8,0.8];
C3 = [0.2,0.4; 0.2,0.8; 0.6,0.2; 0.6,0.6];
C4 = [0.4,0.4; 0.4,0.8; 0.8,0.2; 0.8,0.6];
disp('C1 = ');
disp(C1);
disp('C2 = ');
disp(C2);
disp('C3 = ');
disp(C3);
disp('C4 = ');
disp(C4);

%Taux d'apprentissage:
taux_apprentissage = 0.2;
flag_reduce_taux_apprentisssage = 0;
taux_reduction_taux_apprentissage = 1/100;
taux_apprentissage_minimal = 1/100;

%Autres donn�es importante:
Nb_classes = 4;
max_loop = 1;

%------------------------------------
%V�RIFICATION PARAM�TRES:

[nb_entry, nb_data_in] = size(x);
[nb_classe_x, ~] = size(classe_x);

[nb_C1, nb_data_1] = size(C1);
[nb_C2, nb_data_2] = size(C2);
[nb_C3, nb_data_3] = size(C3);
[nb_C4, nb_data_4] = size(C4);

%1) Nb classe d'entr�e = Nb entr�e
if(nb_entry ~= nb_classe_x)
    disp('LVQ: Error: Nb line X != nb line classe X');
    return;
end
%2) Tous les repr�sentant on le m�me nb de colonne = nb colonne d'entr�e.
if(nb_data_1 ~= nb_data_2 || nb_data_1 ~= nb_data_3 || nb_data_1 ~= nb_data_4 || nb_data_1 ~= nb_data_in)
    disp('LVQ: Error: Nb entry is not constant between X and the reprensentants');
    return;
end

%------------------------------------
%ALGORITHME:
nb_loop = 0;
classe_best_representant = 1;
distance = 0;

while(taux_apprentissage >= taux_apprentissage_minimal && nb_loop < max_loop)
    
    %Boucle sur les vecteurs d'entr�es
    for no_entree=1:nb_entry
        
        %NOTE OPTIMISATION: "sqrt" pas obligatoire puisqu'on ne fait que
        %compar� des distances, mais r�duit risque d�passemetn du type.
        %Puisque l'algo pr�sent� ne l'a pas, ne l'a donc pas mit.
        dist_min = sum((x(no_entree,:) - C1(1,:)).^2);
        no_best_representant = 1;
        classe_best_representant = 1;
        
        %Parcourir les diff�rentes classes de repr�sentant et calculer �
        %chaque fois la distance entre le repr�sentant et l'entr�e et voir
        %si celui-ci est plus proche que le pr�c�dent meilleur
        %repr�sentant.
        for no_classe=1:Nb_classes
            switch(no_classe)
                case 1
                    %Commence � 2, car dist_min initial avec C1(1)
                    for no_representant=2:nb_data_1
                        distance = sum((x(no_entree,:) - C1(no_representant,:)).^2);
                        if(dist_min > distance)
                            dist_min = distance;
                            no_best_representant = no_representant;
                            classe_best_representant = no_classe;
                        end
                    end
                    
                case 2
                    for no_representant=1:nb_data_2
                        distance = sum((x(no_entree,:) - C2(no_representant,:)).^2);
                        if(dist_min > distance)
                            dist_min = distance;
                            no_best_representant = no_representant;
                            classe_best_representant = no_classe;
                        end
                    end
                    
                case 3
                    for no_representant=1:nb_data_3
                        distance = sum((x(no_entree,:) - C3(no_representant,:)).^2);
                        if(dist_min > distance)
                            dist_min = distance;
                            no_best_representant = no_representant;
                            classe_best_representant = no_classe;
                        end
                    end
                    
                case 4
                    for no_representant=1:nb_data_4
                        distance = sum((x(no_entree,:) - C4(no_representant,:)).^2);
                        if(dist_min > distance)
                            dist_min = distance;
                            no_best_representant = no_representant;
                            classe_best_representant = no_classe;
                        end
                    end
            end
        end
      
        disp('Classe best representant = ');
        disp(classe_best_representant);
        disp('Position best representant in classe = ');
        disp(no_best_representant);
        
        %Actualis� le repr�sentant le plus proche de l'entr�e. Pour aid�,
        %on affiche la valeur avant et apr�s la modification.
        if(classe_best_representant == classe_x(no_entree,1)) %M�me classe: Repr�sentant se rapproche de X.
            switch(classe_best_representant)
                case 1
                    disp('Representant before = ');
                    disp(C1(no_best_representant,:));
                    C1(no_best_representant,:) = C1(no_best_representant,:) + taux_apprentissage.*(x(no_entree,:) - C1(no_best_representant,:));
                    disp('New representant = ');
                    disp(C1(no_best_representant,:));

                case 2
                    disp('Representant before = ');
                    disp(C2(no_best_representant,:));
                    C2(no_best_representant,:) = C2(no_best_representant,:) + taux_apprentissage.*(x(no_entree,:) - C2(no_best_representant,:));
                    disp('New representant = ');
                    disp(C2(no_best_representant,:));
                    
                case 3
                    disp('Representant before = ');
                    disp(C3(no_best_representant,:));
                    C3(no_best_representant,:) = C3(no_best_representant,:) + taux_apprentissage.*(x(no_entree,:) - C3(no_best_representant,:));
                    disp('New representant = ');
                    disp(C3(no_best_representant,:));

                case 4
                    disp('Representant before = ');
                    disp(C4(no_best_representant,:));
                    C4(no_best_representant,:) = C4(no_best_representant,:) + taux_apprentissage.*(x(no_entree,:) - C4(no_best_representant,:));
                    disp('New representant = ');
                    disp(C4(no_best_representant,:));
            end
            
        else %Pas m�me classe: Repr�sentant le plus proche est �loign� de X.
            switch(classe_best_representant)
                case 1
                    disp('Representant before = ');
                    disp(C1(no_best_representant,:));
                    C1(no_best_representant,:) = C1(no_best_representant,:) - taux_apprentissage.*(x(no_entree,:) - C1(no_best_representant,:));
                    disp('New representant = ');
                    disp(C1(no_best_representant,:));

                case 2
                    disp('Representant before = ');
                    disp(C2(no_best_representant,:));
                    C2(no_best_representant,:) = C2(no_best_representant,:) - taux_apprentissage.*(x(no_entree,:) - C2(no_best_representant,:));
                    disp('New representant = ');
                    disp(C2(no_best_representant,:));

                case 3
                    disp('Representant before = ');
                    disp(C3(no_best_representant,:));
                    C3(no_best_representant,:) = C3(no_best_representant,:) - taux_apprentissage.*(x(no_entree,:) - C3(no_best_representant,:));
                    disp('New representant = ');
                    disp(C3(no_best_representant,:));

                case 4
                    disp('Representant before = ');
                    disp(C4(no_best_representant,:));
                    C4(no_best_representant,:) = C4(no_best_representant,:) - taux_apprentissage.*(x(no_entree,:) - C4(no_best_representant,:));
                    disp('New representant = ');
                    disp(C4(no_best_representant,:));
            end
        end
    end%fin boucle sur les entr�es = 1 �poque.
    
    %R�duire le taux d'apprentissage (si peu le faire)
    if(flag_reduce_taux_apprentisssage == 1 && taux_apprentissage > taux_apprentissage_minimal)
        taux_apprentissage = taux_apprentissage*(1-taux_reduction_taux_apprentissage);
    end
    
    nb_loop = nb_loop + 1;
end