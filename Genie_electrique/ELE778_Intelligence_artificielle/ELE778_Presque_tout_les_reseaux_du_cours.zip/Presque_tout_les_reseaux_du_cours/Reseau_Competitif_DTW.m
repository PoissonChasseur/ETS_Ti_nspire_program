%% Reseau competitif sans apprentisssage Dynamic Time Warping (DTW)
%{ 
Cours: ELE778
R�seau de neurone comp�titif sans apprentissage Dynamic Time Warping (DTW)
(utilise programmation dynamique)

Par: Vincent Rougeau-Moss (�t� 2017)

Description:
    Introduction:
        La DTW (Dynamic Time Warping) permet de comparer deux ensembles
        (formes) comprenant un nombre diff�rent de vecteurs.

        La DTW d�rive d�une m�thode plus g�n�rale appel�e programmation
        dynamique [1]. 

        La distance calcul�e par cette m�thode est utilis�e entre autres
        pour la classification. 

        Il a �t� d�montr� que le chemin de co�t minimal �tait la somme de
        tous les sous-chemins minimaux [2,3]. 

    Principe:
        Soit deux ensembles de vecteurs A et B, caract�ristiques
        de 2 signaux (de parole par exemple), de longueur I et J :
        A = {a(1), a(2), ..., a(I)} et B = {b(1), b(2), ..., b(J)}, a(i) et
        b(j) sont des vecteurs de dimension n.
    
        La m�thode permet de calculer la distance entre les 2 formes m�me
        si elles sont de dimension diff�rente. 

        La m�thode commence par calculer toutes les distances entre les
        vecteurs A et B, deux � deux. Ces distances sont conserv�es dans un
        tableau : (voir p. 13 doc cours [source 1]).

        La m�thode consiste � rechercher dans ce tableau le chemin le plus
        court, ayant une distance minimale.

        On cumule ces distances minimales lors de la progression dans le
        tableau pour d�terminer la distance cumul�e la plus petite.
        
M�thode de calcul:
    On calcule la distance cumul�e D(i,j), avec i = [1, I] et j = [1, J].
    Des contraites peuvent s'appliquer.
    
    L'algorithme coniste � choisir � chaque it�ration, la distance cumul�e
    D(i,j): D(i,j) = min( D(i-1, j-1), D(i-1, j), D(i, j-1) ) + d(i,j)

    Le r�sultat est normalis�, pour le rendre ind�pendant de la taille des
    2 ensembles (A et B). La distance entre les 2 formes A et B est: 
    dist(A,B) = D(i,j)/(I+J).

R�sultat finaL obtenue:
    Deux vecteurs, un pour A et un pour B, de m�me longueur (soit la
    longueur de celui le plus long) qui repr�sente la combinaison des
    points de chacun des ces vecteurs qui permet une distance minimale.

Algorithme:
    Donn�e initiale:
        Vecteur A et vecteur B (leurs dimensions peuvent �tre diff�rentes)

    Initialisation:
        I = nb_donn�e(A)
        J = nb_donn�e(B)
        D(0,0) = 0;
        Pour i = 1..I: D(i,0) = infinie.
        Pour j = 1..J: D(0,j) = infinie.

    Programme:
        Pour j = 1..J
            Pour i = 1..I
                d = dist(a(i), b(j)) //distance Eucl�dienne entre les 2
                vecteurs de taille n (d'apr�s explication pr�c�dente) (moi)

                D(i,j) = min[ D(i-1,j), D(i-1,j-1), D(i,j-1) ] + d

        D(I,J)/(I+J) //[moi] divisis� toutes les valeurs par (I+J).

Proc�dure pour trouver la distance entre 2 forme "a" et "b" (p.14):
    1) Calculer la plus courte distance s�parant "a" et "b" (DTW)
    2) Aligner les formes a et b
    3) D�duire les nouvelles formes:
        - Ma d�duction: Pour chaque colonne du tableau D -> identifier
        celui ayant distance minimale. Celui-ci permet de d�duire le couple
        (a[i], b[j]) utiliser pour cette colonne dans les nouveaux vecteurs
        a et b.

Note de d�v�loppement:
    Aucun exemple fait en classe ou pr�sent� dans doc (� part un exemple
    avec des variables, mais aucun chiffres). Donne des r�sultats qui
    semble � premi�re vue valide.

    Deux cas ont �t� observ� et on donc n�cessiter 2 formes de
    l'algorithme: 
        - Cas #1: longueur B > longueur A.
        - Cas #2: longueur B < longueur A.
    
    Ceci � n�cessiter un changement du sens du parcours du tableau D d� au
    besoin d'avoir la longueur des deux vecteurs finaux = � la plus grande
    longueur. Ce qui � pour effet de faire en sorte que le plus cours va 
    avoir des points qui se r�p�te dans son nouveau vecteur pour compenser
    sa plus petite longueur. Tandis que le plus long aura toujours 1 fois
    chacun de ces points.

    Deux m�thodes ont �t� faite pour le cas #2 et elle donne toujours les
    m�mes r�sultats. Des optimisations possibles ont �t� not�s dans le
    code, mais le code ici est comme celui montr� en classe afin d'avoir
    un maximum de claret� et de facilit� le d�bogage.

    Dans le cas o� longueur A = longueur B, les cas #1 et cas #2 ne donne
    pas exactement les m�mes r�sultats. Ceci est d� au fait qu'ils
    utilisent pas les m�mes m�thode de parcours de tableau. L'id�al serait
    de garder les deux et d'utiliser celui qui, au total, donne une
    distance total entre les deux vecteurs qui la plus petite. Pour ce
    faire, on pourrait refaire DTW (avec les nouveaux vecteurs) et faire
    somme des distances afin d'ensuite compar� les deux.

    La Ti nspire cx cas (avec exactement le m�me code) donne les m�mes
    r�sultats (ce qui est logique).

Source:
    - Document de cours: Chapitre 4, "Compet-12 july.pdf" (p.12 � 14/33)
%}
clear;
clc;

%------------------------------------------
%DONN�ES INITIAL DU PROBL�ME:
%NOTE: Aucun exemple de �a fait en classe ni exemple num�rique dans le doc
%du cours (source 1).

%Puisque a = [a(1),..., a(I)] et b = [b(1),...,b(J)] o� a(i) et b(j) sont
%des vecteurs � "n" dimension. a et b peuvent �tre des matrices lignes ou
%rectangulaire. On pose donc que nb ligne = les "n" dimensions. Nb colonne
%de "a" = I et Nb colonne de "b" = J.

a = [1, 2, 3, 4, 5; 6, 7, 8, 9, 10; 11, 12, 13, 14, 15];

%nb_data_b < nb_data_a: Cas #2
b = [1, 2, 3, 4; 5, 6, 7, 8; 9, 10, 11, 12];

% nb_data_b > nb_data_a: Cas #1
%b = [1, 2, 3, 4,5, 6; 7, 8, 9, 10, 11, 12; 13, 14, 15, 16, 17, 18];

%nb_data_b = nb_data_a: Cas #1 ou Cas #2 (� mit pour Cas #1)
%b = [1, 2, 3, 4, 5; 7, 8, 9, 10, 11; 13, 14, 15, 16, 17];

disp('a = ');
disp(a);
disp('b = ');
disp(b);

%V�rification validit� informations (voir note plus haut).
[nb_dim_a, nb_data_a] = size(a);
[nb_dim_b, nb_data_b] = size(b);

if(nb_dim_a ~= nb_dim_b)
    disp('Reseau DTW: Error: Nb line A != Nb line B');
    return
end

%------------------------------------------
%1) CALCULE DE LA PLUS COURTE DISTANCE: ALGO DTW

%Nb ligne = nb_data_a+1; Nb colonnee = nb_data_n + 1 (d� � m�thode algo).
%La 1�re ligne et la 1�re colonne = juste des infinie.
D = zeros(nb_data_a+1, nb_data_b+1);

%Remplir la 1�re ligne et la premi�re colonne ajout� avec des infinies.
D(:,1) = Inf; %infinie
D(1,:) = Inf; %infinie
D(1,1) = 0;

%Parcours les 2 boucles dans la partie valide (skip la ligne et colonne
%suppl�mentaire uniquement utilis� pour le calcul).

%NOTE OPTIMISATION: la racine carr� peut �tre skip puisque de toute fa�on
%on va juste compar� les longueurs. Par contre, permet r�duire taille des
%chiffre et r�duire risque d�pass� la taille max du type.

for j=2:(nb_data_b+1) %parcours en colonne de D.
    for i=2:(nb_data_a+1) %parcours en ligne de D.
        d = sqrt(sum((a(:,i-1)-b(:,j-1)).^2));
        D(i,j) = min( min(D(i-1,j), D(i-1, j-1)), D(i,j-1)) + d;
    end
end

%NOTE OPTIMISATION: la normalisation ne sert � rien pour la m�me raison que
%la racine est aussi inutile. Aspect de r�duction des chiffres aussi
%applicable ici.

%Normalis� les longueur pour qu'ils soient ind�pendant du chemin ([moi]
%Inutile puisqu'on fait juste compar� les longeur ensuite, mais l'a fait
%ici juste pour parfaitement suivre l'algorithme.
%Note: Si tient � le faire, devrait le faire dans la boucle et non ici.
D = D./(nb_data_a+nb_data_b);

disp('D = ');
disp(D);

%------------------------------------------
%2) Aligner les formes a et b � partir du tableau et d�duire les nouvelles
%formes.
%Rappel sur m�thode de l'algo et format de D (fait pr�c�dement):
%   - Nb ligne de D = nb colonne de A
%   - Nb colonne de D  = nb colonne de B
%   Donc no ligne de D = no de A. no colonne de D = no de B.
%   Et il ne faut pas oublier que D � 1 ligne et 1 colonen de plus.
new_longueur = max(nb_data_a, nb_data_b);

%Initialiser les 2 nouveaux vecteurs pour les r�sultats.
new_a = zeros(nb_dim_a, new_longueur);
new_b = new_a;

%Pour chaque colonne: choisir la ligne o� valeur min.
%Celui-ci est la combinaison optimis� � mettre pour cette colonne.

%NOTE OPTIMISATION: D�pendant du cas (cas 1 ou 2) et la m�thode de calcul
%(cas 2 seulement), il possible d'au moins fussionner la premi�re boucle
%pr�c�dente avec la premi�re du code qui suit. Certe le code serait moins
%lisible, compr�hensible et facile � d�boguer, mais on va �viter une boucle
%de parcours du tableau pour un des deux sens de parcours. Optimisation pas
%faite pour garder la claret� du code et car oblige � choisir une des deux
%m�thode (et non garder les deux comme c'est le cas actuellement, pour le
%cas 2).

no_ligne_optimise = 0;

%CAS #1: "B" est le plus long (B plus long ou m�me longueur).
if(nb_data_b >= nb_data_a)
    %no ligne -> A
    %no colonne -> B
    
    for j=2:(nb_data_b+1) %parcours en colonne de D.

        %Recherche ligne min dans cette colonne.
        minimum = D(2, j);
        no_ligne_optimise = 2;
        for i=3:(nb_data_a+1) %parcours en ligne de D.
            %Si nouveau min
            if(minimum > D(i,j))
                minimum = D(i,j);
                no_ligne_optimise = i;
            end
        end

        %Assigner la meilleur pair A,B
        new_a(:,j-1) = a(:,no_ligne_optimise-1);
        new_b(:,j-1) = b(:,j-1);
    end
    
%CAS #2: "A" est le plus long: Inverse sens de A pour garder les boucles
%pareilles (le plus simple).
else
    %Note: Les deux m�thodes reviennent au m�me (m�me r�sultats obtenues).
    
    %M�thode #1 serait mieux sur la base qu'utilise moins de m�moire en
    %changeant le sens du parcours au lieu de changer le tableau pour
    %garder la m�me m�thode de parcours.
    choix = 1;

    %M�thode #1: Parcourir le tableau dans l'autre sens.
    %ce qui �vite cr�ation d'un nouveau tableau (lors transpos� tableau D)
    if(choix == 1)
        %no ligne -> A
        %no colonne -> B

        no_colonne_optimise = 0;

        for j=2:(nb_data_a+1) %parcours en ligne de D.

            %Recherche colonne min dans cette ligne.
            minimum = D(j, 2);
            no_colonne_optimise = 2;

            for i=3:(nb_data_b+1) %parcours en colonne de D.
                %fprintf('%d, %d\n',j,i);

                %Si nouveau min
                if(minimum > D(j,i))
                    minimum = D(j,i);
                    no_colonne_optimise = i;
                end
            end

            %Assigner la meilleur pair A, B
            new_a(:,j-1) = a(:,j-1);
            new_b(:,j-1) = b(:,no_colonne_optimise-1);
        end
    
    %----------------------------
    %M�thode #2: Faire transpos� du tableau et gard� m�me ordre de parcours
    %qu'avant. Plus de m�moire utilis�, mais �tait la 1�re id�e que j'ai
    %eu et � permis de s'assurer que m�thode 1 valide sachant que celle-ci
    %est la plus simple � comprendre puisque aucun changement m�thode de
    %parcours.
    elseif (choix == 2)
    
        %no ligne -> B
        %no colonne -> A

        D = transpose(D);
        [nb_line, nb_column] = size(D);

        for j=2:(nb_column) %parcours en colonne de D.

            %Recherche ligne min dans cette colonne.
            minimum = D(2, j);
            no_ligne_optimise = 2;

            for i=3:(nb_line) %parcours en ligne de D.
                %Si nouveau min
                if(minimum > D(i,j))
                    minimum = D(i,j);
                    no_ligne_optimise = i;
                end
            end

            %Assigner la meilleur pair A,B
            new_a(:,j-1) = a(:,j-1);
            new_b(:,j-1) = b(:,no_ligne_optimise-1);
        end
    end
end

disp('new_a = ');
disp(new_a);
disp('new_b = ');
disp(new_b);