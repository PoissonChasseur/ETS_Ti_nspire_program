%% Reseau Competitif sans apprentissage des K-moyennes
%{ 
Cours: ELE778
R�seau de neurone comp�titif sans apprentissage des K-moyennes

Par: Vincent Rougeau-Moss (�t� 2017)

Description:
    L'algorithme des k-moyennes, permet de partitionner une collection
    d'objets en K classes, K �tant un nombre fix� par l'utilisateur. 

    On supposera dans la suite que nos objets o[j] (o� j = [1,N]) peuvent
    �tre repr�sent�s sous forme de vecteurs. 

Algorithme:
    Choisir K oibjet au hasard parmi les objets de la collection. Soient
    (R[1], ..., R[K]) les objects ainsi obtenues et qui sont les
    repr�sentant des K classes (C[1], ..., C[K]).

    Affecter chaque objet de la collection � l'une des classes en fonction
    du repr�sentant le plus proche. [moi: Note: on compare les distances
    seulement avec les repr�sentants de la classe de l'objet). La distane
    est calcul� est la distance Eucl�dienne entre les deux vecteur.

    Calculer de nouveaux repr�sentant pour les classes. Ces nouveaux
    repr�sentant correspondent � la moyenne des objects de la classe. [Moi:
    pour chaque repr�sentant, on fait la moyenne des objets qui ont �t�
    associ� � ce repr�sentant - � V�RIFIER).

    Retourner en 2 tant que la diff�rence (R) entre les anciens et les
    nouveaux repr�sentants est sup�rieur a un seuil fix� (arbitrairement
    petit).

Note de d�v�loppement:
    Algorithme bas� sur celui fait en labo 3 o� � obtenue performance
    parfaite (r�seau LVQ qui ne n�cessite aucun apprentissage apprentissage
    apr�s s�lection des K repr�sentant de chaque classe � l'aide de la
    m�thode des K-moyennes".

    Celui de la Ti ne fonctionne qu'avec 1 groupe d� �
    limitation Ti � tableau 2D (tableau de dimension > 2 n'existe pas).
    
Source:
    - Document de cours: Chapitre 4, "Compet-12 july.pdf" (p.10 et 11/33)
%}
clear;
clc;

%-------------------------------------------
%DONN�ES DE D�PART

%Donn�e d'entrer (une seule classe) (note: Pourrait aussi avoir plus de
%dimension dans Matlab, mais pas en Ti et pas le cas dans l'exemple).
%
%Note: X et repr�sentat sont reli�s -> habituellement repr�sentant prit
%� partir des donn�es (donc � partir des inputs.
x(:,:,1) = [1,1; 1,2; 2,1; 2,2; 5,4; 5,5; 6,4; 6,5]; %1�re classe.
x(:,:,2) = [2,2; 2,3; 3,2; 3,3; 6,5; 6,6; 7,5; 7,6]; %2�me classe.

%Nombre de repr�sentant par classe
K = 2;

%Difference maximal entre new et old repr�sentant (pour tous les
%repr�sentant d'un groupe) -> Tous les repr�sentants de tous les groupes
%doivent respect� cette condition pour arr�ter plus vite le calcul.
seuls_diff_distance_total_max = 10; %Note: Si veut ignorer cette condition d'arr�t, mettre chiffre < 0.

%Nombre de boucle maximal 
max_loop = 1;
%-------------------------------------------
%INITIALISATION DE L'ALGORITHME
%   Choisir les K premier repr�sentant de chaque groupe comme point de
%   d�part de l'algorithme
[nb_input, nb_column, nb_group] = size(x);
representant = zeros(K, nb_column, nb_group);

%Boucle sur les diff�rents groupes
for no_group=1:nb_group
    %Boucle les object de chaque groupe pour enregistrer les K premier de
    %chaque groupe = repr�sentant initial du groupe.
    for no_objet = 1:K
        representant(no_objet,:,no_group) = x(no_objet,:,no_group);
    end
end

%-------------------------------------------
%ALGORITHME DES K-MOYENNES
nb_loop = 0;
flag_end = 0;
distance = 0;
best_distance = 0;
diff_new_old_representant = 0;
no_best_representant_of_the_group = 1;
no_representant_of_the_group = 0;

nb_objet_associer_a_chaque_reprensentant_1_groupe = zeros(size(x(:,:,1))); %Pour la forme de la matrice.

old_representant = representant;

%Boucle jusqu'� crit�re d'arr�t valide
while(flag_end == 0 && nb_loop < max_loop)
    flag_end = 1; %Commence � 1 et va devenir peut-�tre devenir faux plus tard.
    
    %Bocule sur tous les object de la s�lection (boucle sur les diff�rents
    %groupes)
    for no_group=1:nb_group
        
        %Reset les valeurs de comptage et de sommation.
        diff_new_old_representant = 0;
        nb_objet_associer_a_chaque_reprensentant_1_groupe = zeros(K,1);
        
        %Puisqu'on se sert de "representant" pour la sommation, on le reset.
        %on va se servir de "old_representant" pour calcul des distances.
        %D'o� le "old_representant = representant;" au d�but et � la fin
        %des boucles.
        representant(:,:,no_group) = double(0);
        
        %---------------------------
        
        %Boucle sur tout les objects d'une classe/groupe
        for no_objet=1:nb_input
            %�valuer la distane entre l'objet et chacun de ces repr�sentants
            
            no_best_representant_of_the_group = 1;
            best_distance = sum((x(no_objet,:,no_group)- old_representant(1,:,no_group)).^2);
            
            %Boucle sur les repr�sentant pour trouver le repr�sentant (de
            %ce groupe) le plus proche de cet objet
            for no_representant_of_the_group=2:K
                distance = sum((x(no_objet,:,no_group)- old_representant(no_representant_of_the_group,:,no_group)).^2);
                if(best_distance > distance)
                    best_distance = distance;
                    no_best_representant_of_the_group = no_representant_of_the_group;
                end
            end%Fin boucle sur calcul meilleur repr�sentant d'un objet dans le groupe.
            
            %Additionner les valeurs des objets les plus proche associ�s au
            %repr�sentant le plus proche.
            representant(no_best_representant_of_the_group,:,no_group) = representant(no_best_representant_of_the_group,:,no_group) + x(no_objet,:,no_group);
            nb_objet_associer_a_chaque_reprensentant_1_groupe(no_best_representant_of_the_group) = nb_objet_associer_a_chaque_reprensentant_1_groupe(no_best_representant_of_the_group) + 1;
        end%Fin boucle sur les objects d'un groupe
        
        %Faire la moyenne des sommations effectu�s avec les diff�rents
        %repr�sentants. Rappel: Sommation � �t� effectu�s dans
        %"representant".
        for no_representant_of_the_group=1:K
            
            %Cas #1: Aucun objet � distance minimale: remet l'ancien (car
            %l'a effacer pour effectuer la sommation).
            if(nb_objet_associer_a_chaque_reprensentant_1_groupe(no_representant_of_the_group) == 0)
                representant(no_representant_of_the_group,:,no_group) = old_representant(no_representant_of_the_group,:,no_group);
                
            %Cas #2: A obtenue des objets � distance minimal ->
            %repr�sentant modifi� 
            else
                 representant(no_representant_of_the_group,:,no_group) =  representant(no_representant_of_the_group,:,no_group)./nb_objet_associer_a_chaque_reprensentant_1_groupe(no_representant_of_the_group);
                 diff_new_old_representant = diff_new_old_representant + sum(abs(representant(no_representant_of_the_group,:,no_group) - old_representant(no_representant_of_the_group,:,no_group)));
            end
        end %Fin boucle calcul final repr�sentant d'un groupe.
        
        %Mettre � jour le crit�re d'arr�t
        if(flag_end == 1 && diff_new_old_representant < seuls_diff_distance_total_max)
           flag_end = 1;
        else
            flag_end = 0;
        end
    end%Fin boucle sur les diff�rents groupe
    
    nb_loop = nb_loop + 1;
    
    %NOTE IMPORTANTE: � OUBLIER REMPLACER ANCIEN PAR NOUVEAU REPR�SENTANT
    %DANS LE CODE DU LABORATOIRE 3 -> EMP�CHE PROGRESSION DES REPR�SENTANTS
    %(donc actuellement va toujours avoir les m�mes repr�sentants = 0
    %progression -> comme vue par cet algo, cela va devrait am�liorer
    %performance de l'algo (en ayant une meilleur moyenne).
    
    %Si va faire une autre boucle, alors enregistr� les nouveaux
    %repr�sentant � la place des anciens repr�sentants (sinon inutile).
    if(flag_end == 0 && nb_loop < max_loop)
        old_representant = representant;
    end
    disp('Representant = ');
    disp(representant);
end

