%% Reseau Competitif sans apprentissage de Hamming
%{ 
Cours: ELE778
R�seau de neurone comp�titif sans apprentissage de Hamming

Par: Vincent Rougeau-Moss (�t� 2017)

Description:
    Le r�seau de Hamming est un r�seau
    classifieur � maximum de vraisemblance.

    Il peut �tre utilis� pour d�terminer le
    patron le plus proche de la forme d�entr�e.
    Utilise une mesure de similarit� � base de
    la distance de Hamming.

Note importante sur l'Algorithme: 
    Il utilise un autre algo pour trouv� le maximum. Le doc cours propose
    d'utiliser le MAXNET, mais �a pourrait aussi �tre le Chapeau Mexicain
    ou un autre. (C'est un r�seau hybride).

Notation:
    - n = nb unit�s/neurone d'entr�e
    - m = nb unit�s/neurone de sortie
    - e(j) = le "j"�me patron = [ e[1](j); ...; e[i](j); ...; e[n](j) ]

Algorithme:
    (0) Initialisation: Pour i=1..n et j = 1..m: w(i,j) = e[i](j)/2;
    b(j)=n/2.
    
    Pour chaque vecteur d'entr�e x:
        Calcul de l'activation de l'unit�/neurone: a(j) = b(j) + sum[sur
        K](x(i)*w(i,j)) o� j = 1..m (nb sortie).

        Initialiser les activations du MAXNET: y[j](0) = a[j], j = 1..m (nb
        sortie)

        Appel de MAXNET: Trouver le patron qui repr�sente au mieux le
        vecteur d'entr�e X.
   
Note de d�v�loppement:
    En classe: A fait �tape pr�liminaire � Maxnet, mais n'a pas utilis�
    Maxnet. La pr�paration semble faire la m�me chose que ce qu'on a fait
    en classe.

    Semble parfaitement fonctionner avec le code copy-paste du Maxnet.
    Dans la Ti, aurais juste � appeler la fonction ou proc�dure Maxnet pour
    qu'il l'ex�cute. Aurais juste � lui fournir: epsilon, a, l'entr�e et
    max it�ration � faire.

    Dans la Ti, puisque pourrait aussi utiliser un autre Algo que Maxnet
    pour faire le travail, pourrait avoir un "choix" indiquant quel algo
    utilis� (parmi ceux disponible) avec choix o� ne fait rien (comme �a
    peux manuellement choisir par la suite quel algo utilis�).

Source:
    - Document de cours: Chapitre 4, "Compet-12 july.pdf" (p.9 et 10/33)
%}
clear;
clc;

%---------------------------------------
%DONN�ES DE D�PART:

%Les entr�es:
x = [1, 1, -1, -1]; % X = In.

%Les patrons:
e1 = [1; -1; -1; -1];
e2 = [-1; -1; -1; 1];

%---------------------------------------
%PR�PARATION DES DONN�ES AVANT MAXNET
disp('PREPARATION DES DONNNEES');
n = numel(x); %n = nb entr�e = taille des e[#] ou e#.
b = n/2; %m�me "b" pour tous (pour un vecteur d'entr�e sp�cifique au min).

w =[e1,e2]; %e1 = colonne 1, e2 = colonne 2.
w = w./2; %Diviise par 2 les "e".

disp('x = ');
disp(x);

disp('w = ');
disp(w);

a = b + x*w;
disp('a = ');
disp(a);

%---------------------------------------
%MAXNET (code copier-coller du code Matlab de Maxnet fait pr�c�dement).
disp('MAXNET');
[~,nb_neurones] = size(a);
epsilon = 0.2;

flag_arret = 0;
nb_loop = 0;
max_loop = 5;

while(flag_arret == 0 && nb_loop < max_loop)
    a_new = a;
    disp('nb_loop = ');
    disp(nb_loop+1);
    
    %Actualiser les activations de chaque unit�s/neurones
    for i=1:nb_neurones
        somme = 0;
        for j=1:nb_neurones
            if(i ~= j)
                somme = somme + a(1,j);
            end
        end
        a_new(1,i) = a(1,i) - epsilon*somme;
        
        %Fonction d'activation: x si x>0, 0 sinon.
        tempo = a_new(1,i);
        tempo(tempo<0)=0;
        a_new(1,i) = tempo;
    end
    disp('a_new = ');
    disp(a_new);
    
    %Sauvegarde des activations courantes
    a = a_new;
    
    nb_loop = nb_loop + 1;
    
    %Test du crit�re d'arr�t: Si plus d'un noeud a une activation != 0,
    %continuer. Sinon arr�t. %Sommation utilis� car pour raison ??, sum ne
    %marchait pas m�me avec les exemples du site de Matlab.
    if( ~(sum(find(a_new))>numel(a_new)) )
        flag_arret = 1;
    end
end