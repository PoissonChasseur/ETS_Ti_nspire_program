%% Reseau competitif sans apprentissage Maxnet
%{ 
Cours: ELE778
R�seau de neurone comp�titif sans apprentissage Maxnet

Par: Vincent Rougeau-Moss (�t� 2017)

Description:
    R�seau comp�titif qui peut-�tre utilis� pour d�terminer l'unit� la plus
    proche de la forme d'entr�e. 
    Les "n" unit�s du r�seau sont totalement interconnect�es, avec des
    poids sym�triques (tous les poids entre les neurones sont pareilles et
    un poids de 1 pour la r�troaction par rapport � lui-m�me [pour la
    neurone]).
    Il n'y a pas de processus d'apprentissage pour le Maxnet; les poids
    sont fixes.

Algorithme:
    On pose: m = nb neurones = nb unit�s.
    a_j(0) = activation de la neurone "j" (j = 1..m) et "0" = initiale.
    Donc a_j(2) = a_j apr�s deux loop.

    (0) Initialisation des activations et des poids.
    a_j(0) [0 = initial] entr�e de l'unit�s A_j;
    w(i,j) = 1 si i=j [lui-m�me], -epsilon si i != j (les autres)
    epsilon = ]0, 1/m[ (o� m = nb neurone = nb unit�s).

    Note: L'initialisation est inutile, car le calcul fait �a tout seul.

    Tant que condition d'arr�t invalide
        Actualiser les activations de chaque unit�s/neurone j:
            a_j(new) = f[ a_j(old) - epsilon*sum[exclue lui-m�me](a_k(old))
            >> sommation des activations des autres neurones.

        Sauvegarde des activations courantes:
            Pour j = 1..m (toutes les neurones)
                a_j(old) = a_j(new)

        Test du crit�re d'arr�t:
            Si plus d'un noeud a une activation != 0, continuer. Sinon
            arr�t.

Note de d�v�loppement:
    Test� avec succ�s avec un exercice en classe.

Source:
    - Document de cours: Chapitre 4, "Compet-12 july.pdf" (p.2 � 4/33)
%}
clear;
clc;

%DONN�E INITIALE 
%Valeurs de d�part des activations des neurones (ici 4 neurones)
a = [0.2, 0.4, 0.6, 0.8];
[~,nb_neurones] = size(a);
epsilon = 0.2;

flag_arret = 0;
nb_loop = 0;
max_loop = 5;

a_new = a; %Pour la forme de a_new

while(flag_arret == 0 && nb_loop < max_loop)

    disp('nb_loop = ');
    disp(nb_loop+1);
    
    %Actualiser les activations de chaque unit�s/neurones
    for i=1:nb_neurones
        somme = 0;
        for j=1:nb_neurones
            if(i ~= j)
                somme = somme + a(1,j);
            end
        end
        a_new(1,i) = a(1,i) - epsilon*somme;
        
        %Fonction d'activation: x si x>0, 0 sinon.
        tempo = a_new(1,i);
        tempo(tempo<0)=0;
        a_new(1,i) = tempo;
    end
    disp('a_new = ');
    disp(a_new);
    
    %Sauvegarde des activations courantes
    a = a_new;
    
    nb_loop = nb_loop + 1;
    
    %Test du crit�re d'arr�t: Si plus d'un noeud a une activation != 0,
    %continuer. Sinon arr�t. %Sommation utilis� car pour raison ??, sum ne
    %marchait pas m�me avec les exemples du site de Matlab.
    if( ~(sum(find(a_new))>numel(a_new)) )
        flag_arret = 1;
    end
end