%% Reseau_Auto_Associatif (RAS)
%{
Cours: ELE778
R�seau de neurone Auto-Associatif (RAS)
Par: Vincent Rougeau-Moss (�t� 2017)

Description:
    - But de ce type de r�seau: Avoir un r�seau apte � associer des entr�es 
                                avec des sorties sp�cifiques.

    - Caract�ristique: r�seau � 1 couche; chaque association correspond 
                       � une paire de vecteur entr�e-sortie (s:t). s et t
                       �tant identifique.

    - Lexique: Le processus d'entrainement est souvent appel� "stockage" ou
               "m�morisation" (de "storing").

    - Performance: La performance du r�seau est mesur� en fonction de sa
                   capacit� � extraire une forme � partir d'une entr�e
                   bruit�e. Une repr�sentation bipolaire donne de meilleur
                   r�sultat qu'une repr�sentation binaire.

    - Architecture: Feed forward (entr�e vers la sortie). M�me forme
                    d'architecture que pour R�seau H�t�ro-associatif 
                    (n entr�es et m sorties o� toutes les entr�es sont 
                    connect�s � toutes les sorties).

    - Apprentissage: R�gle de Hebb

Note sur Impl�mentation:
    Est exactement pareille au r�seau H�t�ro-associatif, � la diff�rence
    qu'au lieu d'avoir besoin d'un vecteur d'entr�e et de sortie, on a
    juste besoin du vecteur d'entr�e car sortie = entr�e.

    Le code est donc un copy-paste o� seul la sortie n'a pas besoin d'�tre
    d�finie au cours de l'apprentissage (car identique � l'entr�e).

Note de performance (doc cours p. 8 - conclusion):
    Le r�seau ne r�pond pas imm�diatement � l'entr�e d'un signal avec une
    sortie ad�quate. Parfois la r�ponse est assez proche de la sortie
    d�sir� qu'on peut penser utiliser cette sortie comme �tant l'entr�e du
    r�seau.

    Solution: Apprentissage auto-associatif it�ratif.

Ex. d'utilisation:
    - Stocker une forme: Reconnaissance de la forme stock�
    - D�tecter des erreurs dans la forme d'entr�e

Note de d�v�loppement:
    Test� (mode test) avec succ�s sur 1 exercices du cours (exemple 1, p.6).

Source:
    - Document de cours: Chapitre 3, chap3-2-mem-auto.pdf
%}

%APPRENTISSAGE: CALCULER LES POIDS W (en disant qu'initialement W = 0, donc
%n'a pas de poids au commencement - sinon voir apprentissage cycle 2).

% Entr�es: S - Sortie: T. D�but apprentissage: Poids � 0.
clc;
clear;

disp('R�SEAU DE NEURONE � M�MOIRE AUTO-ASSOCIATIVE');
disp('APPRENTISSAGE');
s = [1,0,0,0;1,1,0,0;0,0,0,1;0,0,1,1];
disp('Input = s = ');
disp(s);

t = s;
disp('Output = t = ');
disp(t);

%Pas besoin de s�curit� sur taille matrice, car Sortie = Entr�e.
[nb_data,~] = size(s);

for i=1:nb_data
    if(i == 1)
       w = transpose(s(i,:))*t(i,:);
    else
      w = w + transpose(s(i,:))*t(i,:);
    end
end

disp('Poids = W = ');
disp(w);

% ----------------------------


% APPRENTISSAGE (plusieurs cycles ou � partir poids de d�part)
disp('APPRENTISSAGE - CYCLE 2');
%s = [1,1,0,0;0,1,0,0;0,0,0,1;0,0,1,1];
t = s;

for i=1:nb_data
    w = w + transpose(s(i,:))*t(i,:);
end

disp('Cycle 2: Poids = W = ');
disp(w);

%----------------------------
% TEST:

%Entr�e � utiliser pour le test:

%Calcul l'activation
disp('TEST:');
s = [1,0,0,0;1,1,0,0;0,0,0,1;0,0,1,1];

%Exemple 1 - p.6
%s = [1,1,1,-1];
%w = [1,1,1,-1; 1,1,1,-1; 1,1,1,-1; -1,-1,-1,1];

disp('Input = X = s = ');
disp(s);

a = s*w;
disp('Activation = a = ');
disp(a);

%Fonction d'activation: Si x > 0 -> x = 1; Si x < 0 -> x = -1; sinon x = 0.
y = a;
y(y>0) = 1;
y(y<0) = -1;

disp('Output get = Y = ');
disp(y);
