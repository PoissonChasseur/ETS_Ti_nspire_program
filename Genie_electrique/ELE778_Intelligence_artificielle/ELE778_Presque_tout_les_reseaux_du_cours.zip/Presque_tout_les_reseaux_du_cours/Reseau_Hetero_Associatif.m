%% Reseau_Hetero_Associatif (RHA)
%{ 
Cours: ELE778
R�seau de neurone h�t�roassociatif (RHA):

Par: Vincent Rougeau-Moss (�t� 2017)

Description:
    - But de ce type de r�seau: Avoir un r�seau apte � associer des entr�es 
                                avec des sorties sp�cifiques.

    - Caract�ristique: r�seau � 1 couche; chaque association correspond 
                       � une paire de vecteur entr�e-sortie (s:t). s et t
                       �tant diff�rent.

    - Architecture: Feed forward (entr� vers sortie) et r�ccurente 
                    (connexion ferm�). Toutes les entr�es sont connect�s �
                    toutes les sorties au moyens d'une ligne ayant un
                    poids w(i,j) - n entr�es et m sorties).

    - Apprentissage: R�gle de Hebb.

    - M�moire h�t�roassociatif: T et S sont diff�rents.

Difficult� d'impl�mentation: Tr�s facile
    Se fait tr�s bien avec des calculs matricielles, mais peut aussi se 
    faire sans l'utilisation de Matrice. Revient math�matiquement au m�me.
    Pas besoin de classe ou structure, se fait tr�s bien dans la Ti nspire
    cx cas (fonction ou programme - le plus simple est d'utilis� les
    matrices (puisque aucun m�thode impos�))

Note importante sur format des matrices:
    - Chaque ligne = une donn�e:
        - Une ligne de X = S = une entr�e
        - Une ligne de Y = T = une sortie

    Le but de la m�thode matricielle est d'ex�cuter le calculs sur toutes
    les entr�es et sorties en 1 coup, au lieu de les faire un par un.

    Ainsi, si on veut juste test� (mode test) une entr�e et une sortie, il
    suffit de juste placer les autres lignes avec des 0. M�me chose si veut
    faire moins de couple entr�e-sortie.

    L'important est que le nombre de ligne des matrices soient toujours
    le m�me entre les matrices entr�es-sorties.

Note de d�v�loppement:
    Test� avec succ�s sur 1 exercice du document de cours.

Conclusion du doc cours (p.14/15):
    - Point commun: Les r�sultats obtenus par la r�tropropagation pourrait
                    l'�tre par des m�thodes plus traditionnelles d'analyse
                    de donn�es (analyse discriminante)

    - Avantage: La r�tropropagation s'effectue de mani�re parrall�le.

Note (source 2):
    Dans les cas des r�seau associatif, le r�seau est particuli�rement 
    sensible aux vecteurs d'entr�e non-orthogonaux.
    
    Si l'effet de ces termes de bruit (c'est � dire dus au vecteur
    orthogonaux) n'est pas important, il peut �tre corrig� par une fonction
    de seuils d'activation appliqu� � la sortie; autrement, un modification
    de l'algo d'appretnissage est n�cessaire.

    Voir source 2 pour r�gle delta appliqu� aux m�moires associatives.

Source: 
    - 1) Document de cours: Chapitre 3, chap3-1-mem-ass.pdf
    - 2) http://www.google.ca/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0ahUKEwiahYrmgrLVAhWh7oMKHfCbDgYQFggmMAA&url=http%3A%2F%2Fwww.info2.uqam.ca%2F~boukadoum_m%2FDIC9310%2FNotes%2F6-DIC9310%2520BAM-Hopfield-BSB-.doc&usg=AFQjCNEwsFforQwajvepJA8XdjP7w8PgXQ
      
%}

%APPRENTISSAGE: CALCULER LES POIDS W (en disant qu'initialement W = 0, donc
%n'a pas de poids au commencement - sinon voir apprentissage cycle 2).

% Entr�es: S - Sortie: T. D�but apprentissage: Poids � 0.
clc;
clear;

disp('R�SEAU DE NEURONE � M�MOIRE H�T�RO-ASSOCIATIVE');
disp('APPRENTISSAGE');
s = [1,0,0,0;1,1,0,0;0,0,0,1;0,0,1,1];
t = [1,0;1,0;0,1;0,1];
% s = [1,-1,-1,-1; 1,-1,-1,1; -1,1,-1,-1; -1,1,1,-1];
% t = [1,-1; 1,-1; -1,1; -1,1];

disp('Input = s = ');
disp(s);
disp('Output = t = ');
disp(t);

%Obtenir le nombre de ligne pour entr�e et sortie afin de s'assurer qu'on a
%le m�me nombre d'entr�e et de sortie au total (pour �viter erreur plus
%loin).
[nb_data_s,~] = size(s);
[nb_data_t,~] = size(t);

%V�rification param�tres valide: m�me nb ligne.
if(nb_data_s ~= nb_data_t)
    disp('RHA: Wrong parameters: not same nb lines for input and output');
    return
end

for i=1:nb_data_s
    if(i == 1)
       w = transpose(s(i,:))*t(i,:);
    else
      w = w + transpose(s(i,:))*t(i,:);
    end
end

disp('Poids = W = ');
disp(w);

%----------------------------


% APPRENTISSAGE (plusieurs cycles ou � partir poids de d�part)
disp('APPRENTISSAGE - CYCLE 2');
%s = [1,1,0,0;0,1,0,0;0,0,0,1;0,0,1,1];
for i=1:nb_data_s
    w = w + transpose(s(i,:))*t(i,:);
end

disp('Cycle 2: Poids = W = ');
disp(w);

%----------------------------
% TEST:

%Entr�e � utiliser pour le test:

%Calcul l'activation
disp('TEST:');
s = [1,0,0,0;1,1,0,0;0,0,0,1;0,0,1,1];
%s = [1,1,-1,-1];
disp('Input = X = s = ');
disp(s);

a = s*w;
disp('Activation = a = ');
disp(a);

%Fonction d'activation: Si x > 0, x = 1; Si x < 0, -1; sinon 0.
y = a;
y(y>0) = 1;
y(y<0) = -1;

disp('Output get = Y = ');
disp(y);

    