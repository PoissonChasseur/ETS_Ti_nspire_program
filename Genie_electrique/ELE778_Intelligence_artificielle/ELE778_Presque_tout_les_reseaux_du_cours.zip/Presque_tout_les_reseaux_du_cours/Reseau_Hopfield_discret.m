%% R�seau d'Hopfield discret
%{
Cours: ELE778
R�seau de neurone d'Hopfield discret (r�seau auto-associatif it�ratif)

Par: Vincent Rougeau-Moss (�t� 2017)

Description:
    - But de ce type de r�seau: Avoir un r�seau apte � associer des entr�es 
                                avec des sorties sp�cifiques.

    - Caract�ristiques: Similaire au r�seau r�current autoassiateur; la
                        matrice des poids est sym�trique et les �l�ments de
                        la diagonale sont nuls (sont � 0).

    - Particularit�s: Une seuls unit� est actualis� � chaque fois (mode
                      asynchrone); Chaque unit� re�oit un signal externe en
                      plus du signal re�u des autres unit�s du r�seau.

Algorithme pr�sent� en cours (selon moi, il manque des d�tailles + possible
erreur dans la partie convergence): Rappel: C'est un algo auto-associatif
(entr�e = sortie).

    (0) Initialiser les poids avec la r�gle de Hebb (nom utilis� pour la
    phase d'apprentissage du r�seau h�t�ro et auto associatif).

    Tant qu'il n'y a pas de convergence:
        Pour chaque entr�e x:
            Affecter l'activation � l'entre� x: y(i) = x(i), i = 1..n 
            
            Pour chaque unit�s y(i) (actualis� les unit�s dans un ordre
            AL�ATOIRE):
                Calcul de l'activation: a(i) = xi + sum_sur_j[ y(j)*w(j,i) ]
                Calcul de la fonction d'Activation: y(i) = f[ a(i) ]
                Actualiser le vecteur y
        
        Test de convergence: (je pense que x -> y en fait)
            - x co�ncide avec une forme stock�e
            - x co�ncide avec le x pr�c�dent (n'a pas chang�).
            - Nombre max d'it�rations atteint.

Ex. de fonction d'activation:
           {1 si a(j) > seuils(j)
    y(i) = {0 si a(j) < seuils(j)
           {y(i) sinon [ y(i) si a(j) = seuils(j) ]

Note:
    Le prof ne donne aucun d�taille sur comment faire l'initialisation pour
    avoir la matrice W sous la forme souhait� (pour comme faire pour avoir
    matrice W sym�atrique avec diagonale de 0, alors que n'est pas
    n�cessairement le cas lors r�gle de Hebb).
    
    Le code va donc suppos� que W fournit et on ne fait que test�.
    Pour les exercices, on va aussi supposer que "l'ordre al�atoire" est
    donne�.

Note de d�v�loppement:
    Test� (mode test) avec succ�s avec un exemple fait en classe. 

Source:
    - Document de cours: Chapitre 3, chap3-3-mem-iter.pdf (p.3 � 7/10)
%}
clear;
clc;

%---------------------------
%DONN�ES INITIALES - APPRENTISSAGE:

entree_initial = [1,1,1,-1]; %Sert � construire la matrice W.

[~,nb_entree_initial] = size(entree_initial);

w = transpose(entree_initial)*entree_initial;

%Mettre la diagonale de 0.
for i=1:nb_entree_initial
    for j=1:nb_entree_initial
        if(i==j)
           w(i,j) = 0; 
        end
    end
end

%w = [0,1,1,-1; 1,0,1,-1; 1,1,0,-1; -1,-1,-1,0];
disp('Poids = W = ');
disp(w);

%---------------------------
%DONN�ES INITIALES - TEST

%L'ordre de l'actualisation des unit�s de sorties est: Y_1, Y_4, Y_3, Y_2.

x = [0,0,1,0]; %Entr�e dans l'ordre normal, l'algo va s'occuper de l'ordre ensuite.

y = x; %Juste pour d�finir taille et format de y + pouvoir faire "y_last=y"

[nb_entree,~] = size(x); %Nombre d'entr�e = nb ligne de x.
max_loop = 1; %Nombre d'it�ration maximale.
nb_loop = 0;

%---------------------------
flag_convergence = 0;

%Tant qu'il n'y a pas de convergence:
while(flag_convergence == 0)
    y_last = y; %Pour test convergence.
    
    %Pour chaque entr�e x (une entr�e = une ligne dans la matrice des ent�res):
    for no_entree=1:nb_entree
        
        %[moi]: Choisir l'ordre des actualisations des Y. On va servir de
        %       �a pour choisir les lignes ou colonnes des matrices x,y,w �
        %       utilis� dans les calculs.
        ordre_actualisation = [1, 4, 3, 2];
        
        %Affecter l'activation � l'entre� x: y(i) = x(i), i = 1..n 
        %Note: Ceci est inutile si � fait au d�but: y = x (copie toute la
        %      matrice).
        y(no_entree,:) = x(no_entree,:); %y(ligne_entr�e) = x(ligne_entr�e)
        
        %Pour chaque unit�s y(i): actualis� les unit�s dans un ordre
        %AL�ATOIRE ([moi: l'ordre choisit pr�c�dement])
        for i=1:numel(y)
            disp('i = ');
            disp(i);
            
            %Calcul de l'activation: a(i) = x(i) + sum_sur_j[ y(j)*w(j,i) ]
            %   - y(j) = la ligne "j" de y.
            %   - w(j,i) = la colonne "j" de w (cependant, puisque
            %              sym�trique, ligne ou colonne = les m�mes
            %              chiffres). 
            disp('sum = ');
            disp( sum(y(no_entree,:)*w(:,ordre_actualisation(i)) ));
            a = x(no_entree, ordre_actualisation(i)) + sum(y(no_entree,:)*w(:,ordre_actualisation(i)) );
            
            disp('a = ');
            disp(a);
            
            %Calcul de la fonction d'activation: y(i) = f[ a(i) ]
            %Ici: a > 0 -> 1; a < 0 -> -1 (0 finalement); sinon y (inchang�).
            % + Actualiser le vecteur y
            if(a > 0)
               y(no_entree,ordre_actualisation(i)) = 1;
            elseif (a < 0)
                y(no_entree,ordre_actualisation(i)) = 0;
            end
            disp('y = ');
            disp(y);
        end
    end
    
    %Test de convergence: Ici va rester ultra simple.
    nb_loop = nb_loop + 1;
    
    %V�rifie si "y" n'a pas chang� par rapport derni�re it�ration.
    %et v�rifie si on a atteint le nb max d'it�ration.
    %
    %Devrait aussi v�rifier si y obtenue une sortie correspondand � l'un
    %des cas connues, mais cela d�pend de la situation.
    if(sum(y_last == y) == numel(y) || nb_loop == max_loop)
        flag_convergence = 1;
    else
        disp('Nb loop = ');
        disp(nb_loop);
    end
end


