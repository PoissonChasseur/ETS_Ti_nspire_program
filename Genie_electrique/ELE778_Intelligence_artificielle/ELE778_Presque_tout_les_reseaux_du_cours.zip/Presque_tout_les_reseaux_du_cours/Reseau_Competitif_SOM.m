%% Reseau Competitif avec Apprentissage de la Carte de Kohonen (SOM)
%{ 
Cours: ELE778
R�seau de neurone comp�titif avec Apprentissage de la Carte de Kohonen (SOM)

Par: Vincent Rougeau-Moss (�t� 2017)

Description:
    Le r�seau de neurones d�crit dans ce paragraphe est
    souvent connu sous le nom de carte auto-organisatrice de
    Kohonen (SOM, Self Organized Map).

    Son r�seau peut �tre plusieurs dimension et avoir divers forme pour
    repr�senter la coh�ension entre les noeuds et leurs voisins.
    Ex.: 1D (une ligne), 2D en rectangle ou 2D en hexagone. 

    1. Le r�seau est constitu� de n unit�s d�entr�e (la dimension du signal
    d�entr�e). 
    2. m unit�s de sortie.
    3. Dim (de chaque unit� de sortie)=Dim (unit�s d�entr�e)
    4. Dans ce type de r�seau, m correspond souvent au
    nombre de classes (ou de patrons).
    5. Les poids (vecteurs) sont des mod�les de l�entr�e.
    6. Pendant le processus d�auto-organisation, la classe dont
    le poids est le plus proche (au sens d�une metrique
    donn�e) est consid�r�e comme gagnante.
    7. Les poids de l�unit� gagnante (classe) et des unit�s
    voisines (selon la topologie choisie) sont actualis�s.

Description (exemple g�om�trique - p.19):
    Le r�seau de Kohonen peut �tre vu comme un classificateur dot� d�une
    carte topologique. 
    
    Les �l�ments de la carte correspondent aux unit�s m�mes du r�seau.
    
    Chaque �l�ment a une position (donn�e par le vecteur poids).
    Pour des donn�es � deux dimensions, la position est facile �
    repr�senter.
    
    La t�che est plus complexe pour des dimensions sup�rieures.
    
    Les unit�s dans la carte de Kohonen sont conventionnellement reli�es
    par des lignes. 
    
Notation:
    - unit� = repr�sentant

    - a = taux d'apprentissage.
    
    - Actualiser taux d'apprentissage = les r�duire l�g�rement (ex 1%),
    normalement � faire � tous les N cycles ou �poque, mais peut aussi �tre
    fait � chaque fois (pas conseill� par prof)
    � l'examen, on aura pas � le changer (pas le cas dans les exercices).

Algorithme:
    (0) Initialisation des poids w(i,j): Choix structure du voisinage -
    Initialisation taux d'apprentissage (le ou les "a").
    
    Tant que le crit�re d'arr�t est invalide.
        Pour chaque vecteur d'entre� X
            Pour chaque j ([moi] pour chaque repr�sentant)
                D(j) = sum[sur i][ (w(i,j) - x(i))^2 ]

            Trouver l'index J tel D(J) soit minimum [moi: Trouver le
            repr�sentant le plus proche] 

            Pour toutes les unit�s voisines de J [moi: Pour tous les
            repr�sentants voisin de celui le plus proche de l'entr�e, donc
            au position (ex) ligne � R1 et colonne � R1 et position
            valdie.] 
                w[new](i,j) = w[old](i,j) + a*[ x(i) - w[old](i,j) ]
            
        Actualiser le taux d'apprentissage
            
        R�duire le rayon du voisinage au temps sp�cifi� (m�me princiape
        que pour le chapeau mexicain, d'apr�s les figures p.16 et 17)
        
        Test du crit�re d'arr�t.
        
Observation personnelle:
    En me basant sur l'exemple fait en classe et comparaison avec
    l'algorithme, il semble que les poids = position dans l'espace (sous la
    forme d'un graphique). Les valeurs de l'entr�e X sont aussi vue comme
    des positions dans le graphique (exercice en classe).

    Ceci correspond effectivement bien avec D(j) = distance Eucl�dienne
    entre la position du repr�sentant (par les poids) et l'entr� X. C'est
    juste qu'on a exclue la racine carr�, comme c'est souvent le cas d� au
    fait qu'on a a pas besoin de le faire puisqu'on en fait que comparer
    les donn�es.

Note de d�v�loppement:
    Test� avec succ�s avec un exercice en classe, ce qui m'a permis de
    mieux comprendre l'algo et d'ajout� dans des notes (voir plus haut)
    dans son pseudo-code puisque certains aspects pr�sent� �tait pas clair.
    
    L'algo programm� contient tous les aspects pr�sent�s.

Source:
    - Document de cours: Chapitre 4, "Compet-12 july.pdf" (p.15 �  20/33)
%}
clear;
clc;

%----------------------------------
%DONN�ES INITIALES: Initialisation d�j� faite (donn�e dans le probl�me).

%Vecteur d'entr�e: m�me format que les C, donc m�me nb colonne que les C.
%Chaque ligne = un vecteur d'entre�.
x = [0.5, 0.2];

%Les poids des repr�sentant (les C): chaque ligne = un C.
C = [0.3,0.7; 0.6,0.9; 0.1,0.5; 0.4,0.3; 0.8,0.2];

%Le taux d'apprentissage pour tous le monde.
taux_apprentissage = 0.2;

flag_reduce_taux_apprentissage = 0;
taux_reduction_taux_apprentissage = 1/100; %invent�

%Le rayon: Les repr�sentants aux position � R autour de celui le plus
%proche de l'entr�e seront actualis�. Les autres ne le seront pas. Si 0,
%alors seul celui le plus proche de l'entr�e sera actualis�.
rayon = 1;

flag_reduce_rayon = 0;
reduction_rayon_par_epoque = 1; %doit �tre un chiffre entier (invent�)

%----------------------------------
%V�rification des param�tres

[nb_entry, nb_column_x] = size(x);
[nb_representant, nb_column_c] = size(C);

if(nb_column_x ~= nb_column_c)
    disp('Reseau SOM: Error: X & C not same nb colum');
    return;
end

%----------------------------------
%L'ALGORITHME (version simplifi� pour cas fait en classe)

disp('Entr�e = X = ');
disp(x);

disp('Representant = C = ');
disp(C);

flag_end = 0;

max_loop = 2;
nb_loop = 0;

distance = 0;
dist_min = 0;
no_best_representant = 1;

while(flag_end == 0 && nb_loop < max_loop)
    
    %Boucle sur les vecteurs d'entr�es
    for no_entree=1:nb_entry
        
        %NOTE OPTIMISATION: "sqrt" pas obligatoire puisqu'on ne fait que
        %compar� des distances, mais r�duit risque d�passemetn du type.
        %Puisque l'algo pr�sent� ne l'a pas, ne l'a donc pas mit.
        dist_min = sum((x(no_entree,:) - C(1,:)).^2);
        no_best_representant = 1;
        
        %Boucle sur les repr�sentants: Trouv� celui le proche de l'entr�e.
        for no_representant=2:nb_representant
            distance = sum((x(no_entree,:) - C(no_representant,:)).^2);
            if(dist_min > distance)
                dist_min = distance;
                no_best_representant = no_representant;
            end
        end
        
        disp('Position best representant = ');
        disp(no_best_representant);
        disp('Best reprensetant = ');
        disp(C(no_best_representant,:));
        
        %Actualiser le meilleur repr�sentant et ces voisins (si R > 1)
        for no_representant = (no_best_representant-rayon):(no_best_representant+rayon)
           %V�rification que position valide
           if(no_representant >0 && no_representant <= nb_representant)
              C(no_representant,:) = C(no_representant,:) + taux_apprentissage.*(x(no_entree,:) - C(no_representant,:));
           end
        end
        
        disp('Nouveaux reprensetants: ');
        disp(C);
    end%fin boucle sur les entr�es = 1 �poque.
    
    %Actualiser le taux d'apprentissage (si peut le modifier)
    if(flag_reduce_taux_apprentissage == 1)
        taux_apprentissage = taux_apprentissage * (1 - taux_reduction_rayon);
    end

    %R�duire le rayon du voisinage au temps sp�cifi� (si peux le
    %faire).
    if(flag_reduce_rayon == 1 && rayon > 0)
        rayon = rayon - reduction_rayon_par_epoque;
        if(rayon < 0)
            rayon = 0;
        end
    end

    %Test du crit�re d'arr�t
    nb_loop = nb_loop + 1;
end