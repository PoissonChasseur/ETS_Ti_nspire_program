%% R�seau � M�moire Associative Bidirectionnelle (BAM)
%{
R�seau � M�moire Associative Bidirectionnelle (BAM) (r�seau autoassociateur
r�cursif)
Par: Vincent Rougeau-Moss (�t� 2017)

Description:
    - Une BAM m�morise l'association de patrons
    
    - L'architecture consiste en une couche d'entr�e et une couche de
    sortie connect�es par des liens bidirectionnels.

    - Le r�seau it�re, en avant et en arri�re, en envoyant des signaux
    entre les deux couches jusqu'� ce que tous les neurones atteignent un
    �quilibre (l'activation reste constante).

Source:
    - Document de cours: Chapitre 3, chap3-3-mem-iter.pdf (p.7 � 10/10)
    - Exercice fait en classe
%}
clc;
clear;

%---------------------------------------------------
%DONN�ES INITIALES

%Les vecteurs d'entr�es (1 par ligne)
x = [1,0,1; 0,1,0];

%Les vecteurs de sortie (1 par ligne)
y = [1,0; 0,1];

%---------------------------------------------------
%V�RIFICATION DES PARAM�TRES

[nb_data_x,~] = size(x);
[nb_data_y,~] = size(y);

if(nb_data_x ~= nb_data_y)
    disp('Error: not same nb line for X and Y');
    return
end
%---------------------------------------------------
%ALGORITHME - INITIALISATION: Trouv� poids W

for i=1:nb_data_x
    if(i==1)
        w = transpose(x(i,:))*y(i,:);
    else
        w = w + transpose(x(i,:))*y(i,:);
    end
end

disp('Poids = W = ');
disp(w);

%---------------------------------------------------
%ALGORITHME
nb_loop=0;
while(nb_loop < nb_data_x)
    
   %Alterner entre X et Y comme entr�e.
   disp('No entry = ');
   disp(nb_loop+1);
   
   disp('X as entry');
   disp(x(nb_loop+1,:)*w);
   
   disp('Y as entry');
   disp(y(nb_loop+1,:)*transpose(w));
   
   nb_loop = nb_loop + 1;
end
