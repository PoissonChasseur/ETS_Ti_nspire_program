%% Reseau competitif sans apprentisssage Chapeau Mexicain
%{ 
Cours: ELE778
R�seau de neurone comp�titif sans apprentissage du Chapeau Mexicain.
Par: Vincent Rougeau-Moss (�t� 2017)

Description:
    L�algorithme du chapeau mexicain est un algorithme plus g�n�ral de
    rehaussement du contraste que le Maxnet.
    Il peut y avoir des neurones auxquels un neurone ne serait pas
    connect�. 

    Chaque neurone est connect� avec des poids excitateurs (poids positifs)
    � des neurones voisins coop�ratifs (proche proximit�).
    Chaque neurone est aussi connect� avec des poids inhibiteurs (poids
    n�gatifs) � des neurones voisins comp�titifs (�loign�s).

Architecture:
    Le r�seau est sym�trique autour de chaque neurone.
    Les poids entre une unit� Xi et les plus proches unit�s X(i+1), X(i+1),
    X(i-1), X(i-2), par exemple, sont positif (tr�s souvent la m�me
    valeur).

    Par exemple dans la figure p.6 (o� X(i � 3) sont connect� � X(i) et les
    autres non), les unit�s � l�int�rieur d�un rayon de 2 sont connect�es
    avec des poids positifs. � l�ext�rieur, les poids des connexions sont
    n�gatifs; au-del� de la 3e unit�, il n�y a pas de connexion.

Algorithme et notation:
    Voir p.7 et 8 doc cours ou les notes (�tude chap 4 - 30 juillet 2017)

    Note: n = nb unit�s = nb neurones.

Notation:
    - R2 = Rayon d'interconnexion: X(i) est connect� � X(i � k) pour k
    =1..R2 
    
    - R1 = rayon de la r�gion avec reforcement positif. Entre R1 et R2 =
    renforcement n�gatif.

    - X = vecteur d'activation = S = les entr�es.

    - X_old = vecteur d'activation pr�c�dent.

    - t_max = nombre total d'it�ration

    - s = signal externe = les entr�es = X.

Note de d�v�loppement:
    Test� avec exemple fait en classe et semble valide. Une erreur
    possiblement trouv� dans mes notes de cours pour it�ration 2 (suppos� que erron�
    puisque it�ration 1 parfaite et reste it�ration 2 aussi parfait).

Source:
    - Document de cours: Chapitre 4, "Compet-12 july.pdf" (p.4 � 8/33)
%}
clear;
clc;
%-----------------------------
%DONN�E DE D�PART:
%Entr�e : s = signal externe -> x = s au d�but programme.
s = [0, 0.5, 0.8, 1, 0.8, 0.5, 0];

%Constantes du probl�me (re�ue en param�tre):
R1 = 1;
R2 = 2;
C1 = 0.6;
C2 = -0.4;
t_max = 3;
x_max = 2;
%+ la fonction d'activation.
%-----------------------------
%LE PROGRAMME:

x = s;
nb_neurones = numel(x);

for t=1:t_max
   %Sauvegarder les activations
   x_old = x;
   
   %Calculer les entr�es pour toutes les neurones.
   for i=1:nb_neurones
        somme = 0;
        %Sommation avec C1
        for k=-R1:R1
            position = i + k;
            if(position>0 && position<=nb_neurones)
                somme = somme + x_old(position);
            end
        end
        x(i) = C1*somme;
        
        %Somation avec C2 (partie 1)
        somme = 0;
        for k=-R2:(-R1-1)
            position = i + k;
            if(position>0 && position<=nb_neurones)
                somme = somme + x_old(position);
            end
        end
        x(i) = x(i) + C2*somme;
        
        %Somation avec C2 (partie 2)
        somme = 0;
        for k=(R1+1):R2
            position = i + k;
            if(position>0 && position<=nb_neurones)
                somme = somme + x_old(position);
            end
        end
        x(i) = x(i) + C2*somme;
   end %Fin calcul x_new.
   
   %Fonction d'activation (note: est la m�me que celle pr�sent�
   %pr�c�dement).
   for i=1:nb_neurones
        x(i) = min(x_max, max(0,x(i)));
   end
   
   %Passage vers prochaine loop:
   disp('t = ');
   
   disp(t);
   disp('x_new = ');
   disp(x);
   
end

