%% Reseau_Auto_Associatif_Iteratif / R�seau r�current autoassociateur
%{
Cours: ELE778
R�seau de neurone Auto-Associatif It�ratif / r�current autoassociateur
Par: Vincent Rougeau-Moss (�t� 2017)

Description:
    Caract�ristiques:
        - Chaque unit�s est connect� � toutes les autres
        - La matrice de poids est sym�trique et tous les �l�ments sur la
        diagonale sont nuls (sont � 0).

    Avantage:
        - Cette approche a montr� un meilleur pouvoir de g�n�ralisation.

R�seau r�current autoassociateur:
    Il y  a quelques diff�rence importante par rapport au r�seau
    Autoassociateur (non r�current):
        1) L'apprentissage:
            - R�seau Autoassociateur: W = W + tranpose(Input)*Input
            - R�seau Autoassociateur r�current:  W = W + tranpose(Input)*Input -> Puis met la diagonal � 0

        2) Lors de la phase de test, on va effectuer l'algorithme suivant:
            - Sortie = entr�e*W et nb_loop = 0
            - Tant que Sortie ~= Entr�e et nb_loop < max_loop
                Sortie = Sortie*W
                nb_loop = nb_loop + 1
      
Source:
    - Document de cours: chap3-3-mem-iter.pdf (p.2 seulement).
%}
clc;
clear;

%-------------------------------------------
%DONN�E DE D�PART
disp('R�SEAU DE NEURONE � M�MOIRE AUTO-ASSOCIATIVE IT�RATIF');
x = [1,1,1,1,1,1]; %Entr�e

y = x; %Sortie

max_loop = 2; %Nombre maximale de boucle pouvant �tre effectu�s lors des tests.

disp('Entr�e = X = ');
disp(x);
disp('Sortie = Y = ');
disp(y);

[~,nb_column_x] = size(x);

%-------------------------------------------
%APPRENTISSAGE -> OBTENIR W
disp('APPRENTISSAGE - CYCLE 1');
w = transpose(x)*x;

%mettre la diagonal � 0
for i=1:nb_column_x
    for j=1:nb_column_x
        if(i == j)
           w(i,j) = 0; 
        end
    end 
end

disp('W = ');
disp(w);

%-------------------------------------------
%APPRENTISSAGE - CYCLE 2
x = [1,1,1,-1,-1,-1]; %2�me entr�e
w2 = transpose(x)*x;

%mettre la diagonal � 0
for i=1:nb_column_x
    for j=1:nb_column_x
        if(i == j)
           w2(i,j) = 0; 
        end
    end 
end
w = w + w2;

disp('W = ');
disp(w);

%-------------------------------------------
%TEST:
x = [1,0,0,0,0,0];

%Calcul de la sortie.
y = x*w;

%Fonction d'activation: 1 si x>0, -1 si x <= 0
y(y>0) = 1;
y(y<=0) = -1;

disp('y initial = ');
disp(y);

nb_loop = 0;

%Boucle tant que Sortie diff�rent de l'Entr�e et pas atteint max_loop
while(nb_loop < max_loop && sum(y == x) ~= numel(x))
    %Calcul de la sortie.
    y = y*w;
    
    %Fonction d'activation: 1 si x>0, -1 si x <= 0
    y(y>0) = 1;
    y(y<=0) = -1;
    
    
    disp('y = ');
    disp(y);
    nb_loop = nb_loop + 1; 
end




