%% Exercices_numero_1_Perceptron_Multicouches
%Par: Vincent Rougeau-Moss (�t� 2017)
%----------------------------------------------
% DONN�ES DU PROBL�MES
%----------------------------------------------

%G�n�ral:
entrees = [1,1,0];
sorties = [1,0];
taux_apprentissage = 0.2;

%Couches #1:
poids_entrees_couche1_neurone1 = [0.3, 0.2, 0.2];
poids_entrees_couche1_neurone2 = [0.1, 0.2, 0.4];

seuil_activation_couche1_neurone1 = 0.2;
seuil_activation_couche1_neurone2 = 0;

%Couche #2:
poids_entrees_couche2_neurone1 = [0.4, 0.2];
poids_entrees_couche2_neurone2 = [-0.2, 0.2];

seuil_activation_couche2_neurone1 = 0.1;
seuil_activation_couche2_neurone2 = -0.1;

%Fonction d'activation:
fonction_activation = @(x) tanh(x);
derive_fonction_activation = @(x) 1/((cosh(x)).^2);

%----------------------------------------------
% PHASE 1: ACTIVATION: r�sultat 100% pareille � corrig� prof.
%----------------------------------------------

%Couche #1:
entree_couche_1 = entrees;

i_couche1_neurone1 = sum(entree_couche_1.*poids_entrees_couche1_neurone1) + seuil_activation_couche1_neurone1;
a_couche1_neurone1 = fonction_activation(i_couche1_neurone1);

i_couche1_neurone2 = sum(entree_couche_1.*poids_entrees_couche1_neurone2) + seuil_activation_couche1_neurone2;
a_couche1_neurone2 = fonction_activation(i_couche1_neurone2);

sortie_couche_1 = [a_couche1_neurone1, a_couche1_neurone2];

%Couche #2:
entree_couche_2 = sortie_couche_1;

i_couche2_neurone1 = sum(entree_couche_2.*poids_entrees_couche2_neurone1) + seuil_activation_couche2_neurone1;
a_couche2_neurone1 = fonction_activation(i_couche2_neurone1);

i_couche2_neurone2 = sum(entree_couche_2.*poids_entrees_couche2_neurone2) + seuil_activation_couche2_neurone2;
a_couche2_neurone2 = fonction_activation(i_couche2_neurone2);

sortie_couche_2 = [a_couche2_neurone1, a_couche2_neurone2];

%----------------------------------------------
% PHASE 2: SIGNAL D'ERREUR: 100% pareil, mais erreur_couche1_neurone1 un
% peu diff�rent, mais exactement m�me d�marche que prof.
%----------------------------------------------

%Note: Vient de remarquer que si pas derni�re phase, alors utilise le poids
%de SES SORTIES et NON des ses entr�es. -> Correction � faire dans le code.

%Couche #2: derni�re couche
erreur_couche2_neurone1 = (sorties(1) - a_couche2_neurone1)*derive_fonction_activation(i_couche2_neurone1);
erreur_couche2_neurone2 = (sorties(2) - a_couche2_neurone2)*derive_fonction_activation(i_couche2_neurone2);

erreur_couche2 = [erreur_couche2_neurone1, erreur_couche2_neurone2];

%Couche #1:
erreur_couche1_neurone1 = derive_fonction_activation(i_couche1_neurone1)*(erreur_couche2(1).*poids_entrees_couche2_neurone1(1) + erreur_couche2(2).*poids_entrees_couche2_neurone2(1));
erreur_couche1_neurone2 = derive_fonction_activation(i_couche1_neurone2)*(erreur_couche2(1).*poids_entrees_couche2_neurone1(2) + erreur_couche2(2).*poids_entrees_couche2_neurone2(2));

erreur_couche1 = [erreur_couche1_neurone1, erreur_couche1_neurone2];

%----------------------------------------------
% PHASE 3: Correction: Pareille � prof.
%Puisque l'ordre de ces phases n'a pas d'importane, j'ai gard� le m�me
%ordre celui de la phase 2 pour faire phase 2-3-4 en un coup (commme dans
%le labo).
%----------------------------------------------

%Couche #2:
correction_entrees_couche2_neurone1 = taux_apprentissage*erreur_couche2_neurone1*entree_couche_2;
correction_entrees_couche2_neurone2 = taux_apprentissage*erreur_couche2_neurone2*entree_couche_2;

%Couche #1:
correction_entrees_couche1_neurone1 = taux_apprentissage*erreur_couche1_neurone1*entree_couche_1;
correction_entrees_couche1_neurone2 = taux_apprentissage*erreur_couche1_neurone2*entree_couche_1;

%----------------------------------------------
% PHASE 4: Actualisation des poids: Pareille � prof
%Puisque l'ordre de ces phases n'a pas d'importane, j'ai gard� le m�me
%ordre celui de la phase 2 pour faire phase 2-3-4 en un coup (commme dans
%le labo).
%----------------------------------------------

%Couche #1:
new_poids_entrees_couche1_neurone1 = poids_entrees_couche1_neurone1 + correction_entrees_couche1_neurone1;
new_poids_entrees_couche1_neurone2 = poids_entrees_couche1_neurone2 + correction_entrees_couche1_neurone2;

%Couche #2:
new_poids_entrees_couche2_neurone1 = poids_entrees_couche2_neurone1 + correction_entrees_couche2_neurone1;
new_poids_entrees_couche2_neurone2 = poids_entrees_couche2_neurone2 + correction_entrees_couche2_neurone2;
