%% Zone de test pour ELE747
%Description:
%   Zone de test pour tester des trucs en liens avec ELE747
%------------------------------------
clc;
clear;
close all;

%INITIALISATION - OBTENIR L'IMAGE ET L'AFFICHER
%Obtenir une image:
[image1,map] = imread('standard_test_images\standard_test_images\cameraman.tif');

%Convertir l'image en noir et blanc si elle est en couleur (va planter si
%image d�j� en noir et blanc car map = empty).
if (isempty(map) == 0)
    image1 = ind2gray(image1,map);
end

%Affiche l'image en noir et blanc:
figure(1);
imagesc(image1); %Display image with scaled colors (mieux que "image(image1").
colormap('gray'); %Mettre les couleurs en degr� de gris = en noir et blanc.

%-----------------------------------
%% Histogramme �quilibr� (chap 3 - section 3.3)

%M�thode programm�: 
% [histogramme, image_final] = Histogramme_equilibre(image1);
% histogramme
% figure(2);
% imagesc(image_final);
% colormap('gray'); %Mettre les couleurs en degr� de gris = en noir et blanc.
% 
% figure(3);
% imhist(image_final); %Affichage de l'histogramme via fonction Matlab.
% 
% %M�thode MATLAB: 
% image_hist_eq_Matlab = histeq(image1);
% figure(4);
% imagesc(image_hist_eq_Matlab);
% colormap('gray');
% 
% figure(5);
% imhist(image_hist_eq_Matlab);

%Conclusion: Matlab �quilibre beaucoup mieux que moi, pourtant j'ai
%appliqu� la m�thode tel que vue en classe. Mais le plus important, c'est
%avoir un algo qui fait ce qu'on a vue en classe pour pouvoir le faire �
%l'examen comme vue en classe. L'algo de Matlab est bien s�r meilleur que
%moi et c'est normal, il prend notamment en compte plus de chose que moi (�
%regarder dans "edit histeq")).

%L'algorithme � �t� approuv� par exercice 2.1 et 2.2 (sur Moodle).

%-----------------------------------
%% Intensit� des couleurs : (Chap 3, section 3.2, p. 107 � 117)
% nb_bit_couleur = 8;
% 
% max_value = 2^nb_bit_couleur-1; %Pour Image n�gative.
% c = 1; %Pour log et puissance.
% gamma = 1; %Pour puissance.
% 
% choix = 3; %1 = Image n�gative, 2 = Log, 3 = Puissance.
% 
% [image_final] = Intensity_transformation(image1, max_value, c, gamma, choix);
% figure();
% imagesc(image_final);
% colormap('gray');

%% Convolution et Correlation - algo fait � la main (version Matlab existe aussi).

% filtre = [1,1,1; 1,-8,1; 1,1,1];
% is_convolution = 1; % 1 = convolution, 2 = correlation.
% choix_bordure = 2; % 1 = 0-padding, 2 = wrap-around.
% 
% [image_calcul] = Apply_filtrer(image1, filtre, is_convolution, choix_bordure);
% figure();
% imagesc(image_calcul);
% colormap('gray');
% 
% %Version Matlab:
% image_Matlab = conv2(image1, filtre,'same');
% figure();
% imagesc(image_Matlab);
% colormap('gray');

%% Filtre Laplacien (d�riv� ordre 2)

% is_convolution = 1; % 1 = convolution, 2 = correlation.
% choix_bordure = 2; % 1 = 0-padding, 2 = wrap-around.
% cte_c = 1; %Nb fois multiplie l'intensit� des pixels de l'image obtenue via application Laplacien sur l'image original.
% choix_methode_application_filtre = 1; % Ma m�thode = 1; M�thode Matlab = 2.
% 
% choix_laplace = 2; % 1 = V1+; 2 = V1-; 3 = V2+; 4 = V2-.  
% 
% [image_calcul, image_apres_filtre] =  Filtre_Laplacien(image1, cte_c, is_convolution, choix_methode_application_filtre, choix_laplace, choix_bordure);
% figure();
% imagesc(image_apres_filtre);
% colormap('gray');
% 
% figure();
% imagesc(image_calcul);
% colormap('gray');

%% Filtre du Gradient (d�riv� ordre 1)

% is_convolution = 1; % 1 = convolution, 2 = correlation.
% choix_bordure = 2; % 1 = 0-padding, 2 = wrap-around.
% 
% %Pour le moment, seul les no 4,5 et 6 possible, car pas encore apte �
% %appliquer filtre aux dimensions pair ("Apply_filtrer" pas encore adapt�
% %pour �a).
% choix_gradiant = 6; %1) Robert_X; 2) Robert_Y; 3) Robert_X_Y; 4) Sobel_X; 5) Sobel_Y; 6) Sobel_X_Y.
% 
% [image_calcul] = Filtre_gradient(image1, is_convolution, choix_gradiant, choix_bordure);
% figure();
% imagesc(image_calcul);
% colormap('gray');

%% Filtre de la moyenne
% Le filtre de la moyenne constitue simplement � faire la convolution du
% filtre sur l'image, puis de divis� les valeurs de l'image par la somme
% des valeurs du filtre. C'est aussi simple que �a -> voir p.153, eq. 3.5-1
% On peut aussi faire l'inverse et mettre le filtre en d�cimale d�s le
% d�but � la place (souvent plus simple, car pas besoin de transf�rer
% l'image en double puis en uint8, le temps de faire la manipulation).

% filtre = [1,2,1; 2,4,2; 1,2,1];
% filtre = (1./sum(sum(filtre))).*filtre;
% is_convolution = 1; % 1 = convolution, 2 = correlation.
% choix_bordure = 2; % 1 = 0-padding, 2 = wrap-around.
% 
% [image_calcul] = Apply_filtrer(image1, filtre, is_convolution, choix_bordure);
% 
% figure();
% imagesc(image_calcul);
% colormap('gray');
% 
% %Version Matlab:
% image_Matlab = conv2(image1, filtre,'same');
% figure();
% imagesc(image_Matlab);
% colormap('gray');


%% Filtre M�dian
%L'image pour ce cas qui � �t� choisie = image utilis� par manuel o� � un
%cas de bruit "sel et poivre" = mieux pour voir l'impact de ce filtre.
%En plus, on peut comparer ce qu'on obtient avec la figure 3.35 p.157
%-------------------------
% [image1,map] = imread('DIP3E_CH03_Original_Images\Fig0335(a)(ckt_board_saltpep_prob_pt05).tif');
% if (isempty(map) == 0)
%     image1 = ind2gray(image1,map);
% end
% figure(1);
% imagesc(image1); %Display image with scaled colors (mieux que "image(image1").
% colormap('gray'); %Mettre les couleurs en degr� de gris = en noir et blanc.
% %-------------------------
% 
% largeur_cote_filtre = 5; %Doit �tre un nb impair.
% size_filtre = [largeur_cote_filtre, largeur_cote_filtre];
% 
% choix_bordure = 2; % 1 = 0-padding, 2 = wrap-around.
% 
% [image_final] = Filtre_Median(image1, size_filtre, choix_bordure);
% figure();
% imagesc(image_final);
% colormap('gray');

%% Filtre de Gauss (�quation domaine spatial - p.151, section 3.4.3)
%Bas� sur courte description expliqu� dans la section 3.4.3, p.151.
%Filtre de Gauss utilis� ici = filtre passe-bas selon la prof.

% largeur_cote_filtre = 5; %Doit �tre un nb impair.
% size_filtre = [largeur_cote_filtre, largeur_cote_filtre];
% 
% choix_bordure = 2; % 1 = 0-padding, 2 = wrap-around.
% is_convolution = 1; %1 = convolution, 0 = corr�lation.
% 
% %�quation du filtre de Gauss:
% ecart_type_Gauss = 3; %L'�cart-type est ici fixe, mais pourrait aussi d�pendre des voisin (manuel ne l'a pas encore fait).
% fonction = @(x,y) exp( -(x.^2+y.^2)/2*ecart_type_Gauss^2);
% 
% %Ex�cution du calcul et image obtenue:
% [image_final] = Apply_Equation_Spatial_filtrer(image1, fonction, size_filtre, is_convolution, choix_bordure);
% figure();
% imagesc(image_final);
% colormap('gray');