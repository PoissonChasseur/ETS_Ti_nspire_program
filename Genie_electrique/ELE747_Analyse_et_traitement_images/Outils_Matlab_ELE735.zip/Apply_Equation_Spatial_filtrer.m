%% Apply_Equation_Spatial_filtrer
%{
Titre: Apply_Equation_Spatial_filtrer
Cours: ELE747 - session Automne 2017
Par: Vincent Rougeau-Moss

Description:
    L'objectif de cette fonction est d'appliquer un filtre d�finit par une
    �quation mise pour le domaine spatial sur la forme d'un filtre de
    matrice qu'on applique sur l'ensemble de l'image.

    Contrairement � ce que j'avais mal compris au d�but pour la courte
    explication de l'�quation p.151, section 3.4.4, puisque la fonction ne
    d�pend pas de l'intensit� des pixels (pour les cas couvert ici, comme
    Gauss dans le texte cit� plus haut), on a juste besoin de construire la
    matrice du filre puis de l'appliquer via "Apply_filtrer.m".

    Il est � noter que le code suivant est bas� sur une tr�s courte
    explication dans le chap. 3 qui parle bri�vement de Gauss. Des m�hodes
    notamment pr�sent� dans chap. 4 (Filtre id�al, Butterworth et Gaus via
    domaine Fr�quentielle) et chap. 5 (porte beaucoup sur filtre
    non-lin�aire comme Gauss) n'ont pas �t� �tudier lors de la r�daction de
    code. Ainsi, des m�thodes surement plus avanc� que le code suivant et
    plus optimal sont tout � fait possible.

Note:
    La "fonction" envoy� doit uniquement utiliser les variables symboliques
    (x,y) qui d�crive la position sur l'image dans le domaine spatial.
    Toutes les autres variables doivent avoir d�j� pr�alablement �t� misent
    sous la forme num�rique.

Param�tres:
    - image = l'image compl�te (o� la partie � modifier)
    - fonction = f(x,y) de l'�quation � utiliser pour le filtre dans le
                 domaine spatial.
    - size_filtre = dimension (nb impair) du filtre
    - is_convolution = 1 si utilise convolution, 0 si corr�lation
    - choix_bordure = m�thode � utiliser pour les bordures (voir
                      "Get_value_image_bordures.m").

--------------------------------------------------------------------
%}
function [image_final] = Apply_Equation_Spatial_filtrer(image, fonction, size_filtre, is_convolution, choix_bordure)
    image = im2double(image);
    image_final = image;
    
    size_image = size(image);
    if(numel(size_image)==2)
       size_image = [size_image,1]; 
    end
    if(numel(size_filtre)==2)
       size_filtre = [size_filtre,1]; 
    end
    %---------------------------
    %V�rification des param�tres
    if(size_filtre(1) > size_image(1) || size_filtre(2) > size_image(2) || size_filtre(3) > size_image(3))
       disp('Error: Image is to much small for the filtrer');
       return;
    elseif( choix_bordure < 1 || choix_bordure > 2)
        disp('Error: choix_bordure choice are 1 or 2');
        return;
    elseif( mod(size_filtre(1),2) == 0 || mod(size_filtre(2),2) == 0 || mod(size_filtre(3),2) == 0)
       disp('Error: Code not adapted for case filtrer have dimension not odd (impair)');
       return;
    end
    %---------------------------
    %D�but du programme:
    
    %Construction de la matrice du filtre � partir de l'�quation.
    a = (size_filtre(1)-1)/2;
    b = (size_filtre(2)-1)/2;
    
    decalage_ligne = a + 1; %D�calage n�cesaire d� � d�but matrice � (1,1) - si d�bute � (0,0), enlever le "+1".
    decalage_colonne = b + 1;
    
    filtre = zeros(size_filtre);
    
    for s=-a:a
        for t=-b:b
            filtre(s+decalage_ligne,t+decalage_colonne) = fonction(s,t);
        end
    end
    
    %Application du filtre obtenue sur l'image.
    [image_final] = Apply_filtrer(image, filtre, is_convolution, choix_bordure);
    
    %Reconversion de l'image - va supposer pour l'instant qu'est toujours
    %en unint8 (se fait d�j� part "Apply_filtrer").
end

