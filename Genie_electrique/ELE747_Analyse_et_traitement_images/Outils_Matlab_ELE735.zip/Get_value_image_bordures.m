%% Get_value_image
%Description:
%   Fonction qui retourne la valeur du pixel de l'image en fonction de la
%   m�thode pour les bordures qui � �t� choisie.
%
%   Si veut l'optimiser, alors devrais d'abord faire tout sauf les
%   bordures, puis ensuite l'utiliser uniquement sur les bordures.
%   Cependant, sera moins g�n�raliser ou demanderas plus de code de
%   v�rification.
%
%   Puisque c'est une fonction priv�, on ne fait aucune v�rification des
%   param�tres. Cette m�thode est notamment utilis� par "Apply_filtrer" (o�
%   �tait inialement ce code) et "Filtre_Median" et possiblement d'autre
%   filtre qui ne peuvent pas passer par "Apply_filtrer" pour pouvoir �tre
%   appliqu� sur l'image tout simplement car on ne peut pas mettre
%   l'algorithme sous la forme d'une matrice � appliquer sur l'image.
%
%Param�tres et caract�ristique importante:
%   - image: d�j� mit sous la forme de double via "im2double" et
%             g�n�ralement sera l'image original et non celle en cours de
%             modification (afin de se baser sur les valeurs original des
%             voisins et non celle d�j� modfier).
%
%   - nb_line_image, nb_column_image, dim_image = size(image) en 3D.
%   - i,j,k = position du pixel qu'on souhaite aller chercher sur l'image
%   - choix_bordure = le no de la m�thode choisit pour le cas des bordures.
%       1) 0-padding: Si sort bordure, alors valeur � l'ext�rieur � 0.
%       2) wrap-around (m�thode du prof et la meilleur m�thode).
%
function [pixel] = Get_value_image_bordures(image, nb_line_image, nb_column_image, dim_image, i,j,k, choix_bordure)
    switch(choix_bordure)
        case 1 % 0-padding: Si sort bordure, alors valeur � l'ext�rieur � 0.
            if(i > nb_line_image || i <= 0 || j > nb_column_image || j <= 0 || k > dim_image || k <= 0)
               pixel = 0;
            else
                pixel = image(i,j,k);
            end
        
        case 2 % wrap-around (m�thode du prof et la meilleur m�thode).
            pixel = image(modulo(i,nb_line_image), modulo(j,nb_column_image), modulo(k,dim_image));
    end
end

function [result] = modulo(a,b)
    result = mod(a,b);
    if(a >= b || result == 0) %2 cas possible, soit je d�passe, soit j'ai �t� � 0 � cause (ex.) soustratraction de la convolution.
       result = result + 1; %N�cesaire, car d�bute � 1 et non � 0.
    end
end


%% Verifie_pos_not_bordure
%Description:
%   Retourne 1 si pos demand� pas dans les bordures de l'image. 0 si c'est
%   le cas. Peut �tre utile pour �viter calcule suppl�mentaire inutile.
%--------------------------