%% Filtre_Median
%{
Titre: Filtre_Median (filtre passe-bas).
Cours: ELE747 - session Automne 2017
Par: Vincent Rougeau-Moss

Description:
    Le filtre m�dian est surtout id�al pour les cas o� on a un bruit de
    type "poivre et sel", soit un bruit pr�sent sur toutes l'image et de
    mani�re al�atoire, un peu comme si on avait d�pos� du poivre ou/et du
    sel sur les objets prit en photo. En utilisant la m�diane des valeurs
    des pixels dans une certaine r�gion local autour de chaque pixel, comme
    valeur du pixel, on r�ussi � �liminer se bruit. Voir description dans
    section 3.5.2, p.156-157 du manuel.

    C'est un filtre passe-bas, notamment car le bruit "poivre et sel"
    correspond � beaucoup de variaiton d'intensit� = zone de haute
    fr�quence. Or, c'est justement ce qu'on �limine.

Note de d�v�loppement:
    Test� sur image du manuel (figure 3.35 p.157) et semble tr�s bien
    fonctionn�.

    Test� avec exercice 3.2 (Moodle) et donne le m�me r�sultat que la
    fonction Matlab.

Code Matlab �quivalent:
    size_filtre = [3,3];
    Figure1_median = medfilt2(image, size_filtre);

    Note: La fonction Matlab utilise le 0-padding pour les bordures.

Param�tres:
    - image = L'image original au complet.
    - size_filtre = les dimensions (nb impair) du filtre 2D.
    - choix_bordure = m�thode choisit pour les bordures (voir
                      Get_value_image_bordure)
--------------------------------------------------------------------
%}
function [image_final] = Filtre_Median(image, size_filtre, choix_bordure)
    image = im2double(image);
    image_final = image;
    size_image = size(image);
    
    if(numel(size_image) == 2)
       size_image = [size_image, 1]; 
    end
    if(numel(size_filtre) == 2)
       size_filtre = [size_filtre,1]; 
    end
    
    %----------------------------
    %V�rification des param�tres:
    if(size_filtre(1) > size_image(1) || size_filtre(2) > size_image(2) || size_filtre(3) > size_image(3))
       disp('Error: Image is to much small for the filtrer');
       return;
    elseif( choix_bordure < 1 || choix_bordure > 2)
        disp('Error: choix_bordure choice are 1 or 2');
        return;
    elseif( mod(size_filtre(1),2) == 0 || mod(size_filtre(2),2) == 0 || mod(size_filtre(3),2) == 0)
       disp('Error: Code not adapted for case filtrer have dimension not odd (impair)');
       return;
    end
    %----------------------------
    %D�but du programme:
    a = (size_filtre(1)-1)/2;
    b = (size_filtre(2)-1)/2;
    
    %Parcour toute l'image en appliquant ce filtre.
    for i=1:size_image(1)
        for j=1:size_image(2)
            for k=1:size_image(3)
                image_final(i,j,k) = Calcul_Median_1_pixel(image, size_image, a, b, i,j,k, choix_bordure);
            end%fin loop dim image
        end
    end
    
    image_final = im2uint8(image_final);
end

%% Calcul_Median_1_pixel
%Description:
%   Fonction qui effectue le calcul du filtre de la m�diane par rapport � 1
%   pixel de l'image.
%
%Note:
%   A beaucoup de similarit� avec "Calculate_1_pixel" de "Apply_filtrer.m".
%
%Note:
%   Dans l'exercice 3.2 avec 0-padding, m�me r�sultat avec Corr�lation ou
%   Convolution. � donc laisser en convolution comme avec les autres
%   (habituellement est celle que le manuel + prof parle).
%
%Param�tres:
%   - image = l'image original o� applique le filtre.
%   - size_image = size(image) o� s'assure d'avoir les 3 dimensions.
%   - a,b = en lien avec dimension du filtre (voir p.148 manuel). 
%   - i,j,k = position du pixel sur l'image avec lequel effectue le calcul.
%   - choix_bordure = la m�thode � utiliser pour le cas des bordures.
%----------------------------------
function [pixel] = Calcul_Median_1_pixel(image, size_image, a, b, i,j,k, choix_bordure)
    %Contruire la zone de l'image o� doit faire la m�diane.
    %Note: D'autre m�thode (genre capture ou truc comme �a) avec outils
    %Matlab aussi possible, mais ne serait pas applicable pour autre chose
    %que Matlab o� devra faire un truc comme ici.
    zone_filtre = zeros(2*a+1, 2*b+1);
    
    decalage_ligne = a + 1; %D�calage n�cesaire d� � d�but matrice � (1,1) - si d�bute � (0,0), enlever le "+1".
    decalage_colonne = b + 1;
    for s=-a:a
        for t=-b:b
            zone_filtre(s+decalage_ligne,t+decalage_colonne) = Get_value_image_bordures(image, size_image(1), size_image(2), size_image(3), i-s, j-t, k, choix_bordure);
        end
    end
    
    %Calculer la m�diane de cette zone = la valeur du pixel
    pixel = Med_matrice(zone_filtre, numel(zone_filtre));
    
    %pixel = median(median(median(zone_filtre))); %Ne donne pas toujours le
    %bon r�sultat (a vue �a via exercice 3.2).
    
%     if(pixel == 1 && i <= 6 && j <= 6)
%        disp('A\n'); 
%     end
    
end

%% Med_matrice
%Description:
%   1) Met la matrice sous forme d'un long vecteur ligne
%   2) Le trie en ordre croisant
%   3) Va chercher la m�diane.
%
%   Puisque 2 et 3 combin� dans median(), fait juste "median".
%   La raison de son utilisation est d� au fait que faire
%   median(median(matrice))  ne donne pas n�cessairement la bonne valeur.
%   C'est ce que j'ai trouv�  via l'exercice 3.2 o� avait 5 z�ro et 4 un et
%   j'ai obtenue 1. Or, la bonne r�ponse est 0.
%
%   Gr�ce � �a, j'obtient maintenant le m�me r�sultat que celui obtenue via
%   la fonction Matlab.
%
%   Il ne faut pas oublier que certaines adaptation serait n�cessaire pour
%   le cas o� l'image est en couleur (ex.: ne consid�rer qu'une valeur de
%   couleur � la fois).
%
%Param�tres:
%   - matrice_original = La matrice pour lequel on veut avoir la m�diane.
%   - nb_element_matrice = numel(matrice).
%
function [mediane_matrice] = Med_matrice(matrice_original, nb_element_matrice)
    matrice_original = reshape(matrice_original,[1,nb_element_matrice]);
    mediane_matrice = median(matrice_original);
end


