%% Filtre_Laplacien
%{
Titre: Filtre_Laplacien
Cours: ELE747 - session Automne 2017
Par: Vincent Rougeau-Moss

Description:
    On utilise le Laplacien (la d�riv� seconde) afin de mettre en �vidence
    les contours, ce qui en constitue un filtre spatial passe-haut o� la
    fr�quence, en imagerie, correspond � la diff�rence, en valeur absolue,
    de la valeur entre 2 pixels, soit le changement de valeur entre 2
    pixels.

Note:
    On consid�re ici que l'image_compl�te = toute l'image, ce qui est
    important pour le cas o� utilise "wrap-around" aux bordures.
    
    Plein de m�thode possible pourrait �tre utiliser pour les bordures et
    pourrait �tre impl�menter par la suite.

--------------------------------------------------------------------
%}

function [image_final, image_apres_filtre] = Filtre_Laplacien(image_complete, cte_c, is_convolution, choix_methode_application_filtre, choix_laplace, choix_bordure)
    laplacian_V1_plus = [0,1,0; 1,-4,1; 0,1,0];
    laplacian_V1_minus = - laplacian_V1_plus;
    
    laplacian_V2_plus = [1,1,1; 1,-8,1; 1,1,1];
    laplacian_V2_minus = - laplacian_V2_plus;
    
    %---------------------------------------
    %D�but du programme: 
    
    %Obtenir le filtre � utiliser.
    switch(choix_laplace)
        case 1 % laplacian_V1_plus
            laplacian = laplacian_V1_plus;
        case 2 % laplacian_V1_minus
            laplacian = laplacian_V1_minus;
        case 3 % laplacian_V2_plus
            laplacian = laplacian_V2_plus;
        case 4 % laplacian_V2_minus
            laplacian = laplacian_V2_minus;
    end
    
    %Appliquer le filtre sur l'image pour obtenir le r�sultat apr�s
    %application du filtre passe-haut. Note: Manuel ne met pas "abs" sur
    %r�sultat de "conv2", mais la prof le fait, car on a des valeurs
    %n�gatives (selon la prof), ce passe de gris vers noir la couleur de
    %l'image. Moi = en noir, donc semble �tre la bonne chose � faire, m�me
    %si en fessant �a image de Matlab perd les nuances que j'ai aussi de
    %pr�sente lorsque cette image de Matlab est en gris.
    switch(choix_methode_application_filtre)
        case 1 % Ma m�thode que j'ai programm�.
            [image_final] = Apply_filtrer(image_complete, laplacian, is_convolution, choix_bordure);
            
        case 2 %La m�thode de Matlab. - note incertain sur la bonne fonction Matlab pour correlation 2D, deux possibles.
            switch(is_convolution)
                case 1 % Convolution 2D
                    image_final = conv2(image_complete, laplacian, 'same');
                    image_final = abs(image_final); % Prof le fait, mais manuel le fait pas = incertain si n�cessaire.
                    
                case 2 % Correlation 2D - incertain sur laquelle des deux m�thodes prendre (ou si doit prendre une autre).
                    image_final = corr2(image_complete, laplacian); % 2-D correlation coefficient
                    %image_final = xcorr2(image_complete, laplacian); % 2-D cross-correlation
            end
    end
    
    %Appliquer le r�sultat obtenue sur l'image afin d'augmenter les
    %constraste des contours (des zones � haute fr�quence = variation
    %importante de couleur entre les pixels) (en th�orie). 
    image_apres_filtre = image_final;
    
    image_final = im2double(image_final);
    image_complete = im2double(image_complete);
    
    image_final = image_complete + cte_c.*image_final;
    
    image_final = im2uint8(image_final);
end




