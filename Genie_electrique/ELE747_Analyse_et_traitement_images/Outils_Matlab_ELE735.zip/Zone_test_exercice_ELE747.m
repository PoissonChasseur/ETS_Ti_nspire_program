%% Zone_test_exercice_ELE47
%Description:
%   L'objectif du code ici pr�sent est de simplement faire les exercices de
%   ELE747 en utilisant sans probl�me le Tools box d'imagerie de Matlab.
%------------------------------------------------
clc;
clear;
close all;
%% Exercice 2.1: Histogramme �quilibr�
% %L'image de Clown en noir et blanc � �t� mit dans la matrice suivante
% %ayant 88 colonnes et 46 lignes. la matrice qui suit est celle qu'on aurait
% %extraite de l'image (car image du clown ne se trouve pas dans le manuel =
% %pas dans la base de donn�e du manuel (pour version 3 du manuel)).
% 
zone_image = [3,0,1,0,1,0,1,4,11,4,19,9;
              0,1,0,1,0,1,0,4,1,8,11,5;
              1,0,0,0,0,0,1,0,1,8,8,5;
              0,1,0,1,0,1,0,1,1,8,8,8;
              4,1,1,0,1,0,1,1,8,8,8,8;
              3,4,1,3,1,3,1,9,8,12,12,11;
              8,4,8,8,12,8,11,11,11,11,11,8;
              4,8,8,12,8,11,11,11,11,11,10,8;
              8,10,8,11,11,11,12,14,11,8,8,4;
              8,11,8,11,11,15,9,11,5,8,1,4;
              8,8,8,4,8,8,8,4,4,1,1,1;
              4,8,5,4,4,4,1,4,1,4,1,4];
% 
% [histogramme, image_final] = Histogramme_equilibre(zone_image);
% histogram(image_final); %Affiche un histogramme de l'image
% 
% %R�SULTAT: PARFAIT, algo d�v�lopp� est pareille � l'algo prof et donne le
% %m�me r�sultat final.
%--------------------------------------------------
%% Exercice 2.2: Histogramme �quilibr� + fonction s = T(r) donn�e.
% 
% [m,n] = size(zone_image);
% figure_3 = zone_image;
% for i=1:m
%     for j=1:n
%         figure_3(i,j) = T_de_Exercice_2_2(zone_image(i,j));
%     end
% end
% 
% %Note: L'histogramme obtenue n'est pas le bon, car pour raison ???,
% %contrairement � no 2.1, il regroupe des valeurs ensemble. Cependant, la
% %r�ponse obtenue est la bonne (la matrice finale est la bonne).
% %En mettant "nbins" � 20, c'est mieux, m�me si pas parfait. Le chiffre
% %"17.5" n'aide surement pas et cause possiblement ce probl�me pas pr�sent
% %avant. � donc ajout� un "round" pour �viter ce probl�me.
% figure()
% histogram(figure_3,20);
% 
% %R�SULTAT: PARFAIT.
% 
% function [s] = T_de_Exercice_2_2(r)
%     if(r >= 5 && r <= 16) %r = [5,16]
%         s = 10;
%     elseif(r < 5 && r >= 0) %r = [0, 5]
%         s = 2.*r;
%     elseif(r > 16 && r <= 20) % r = [16,20]
%         s = 2.5.*r-30;
%     end
%     s = round(s);
% end
%--------------------------------------------------
%% Exercice 3.2: Appliquer filtre Passe-bas de la moyenne et de la m�diane
%Puisque le no demande d'appliquer le filtre seulement sur le 1er quadrant
%en utilisant m�thode du 0-padding aux bords, il suffit d'appliquer l'algo
%sur toute la matrice, puis de le red�coup� pour donner seulement le 1er
%quadrant. Pas besoin de faire plus compliqu� que �a.
%
%La 1�re question demande le filtre de la m�diane.
%La 2�me question demande le filtre de la moyenne
%Les deux utilise un filtre sur une r�gion 3 X 3.
%---------------
% % #1: APPLIQUER LE FILTRE DE LA M�DIANE.
% size_filtre = [3,3];
% choix_bordure = 1; %1) 0-padding: Si sort bordure, alors valeur � l'ext�rieur � 0. 2) Wrap-around.
% 
% %Note importante: Doit mettre en commentaire la ligne "image_final = im2uint8(image_final);" 
% %                 pour �viter de changer les valeurs � la fin.
% [image_final] = Filtre_Median(zone_image, size_filtre, choix_bordure);
% image_final = image_final(1:6,1:6); %Conserver seulement le 1er quadrant.
% image_final
% 
% %Version Matlab (corrig� du no + quelque truc pour �tre �quibalent sur imcrop):
% Figure1_median = medfilt2(zone_image, size_filtre);
% Figure1_median(1:1:6,1:1:6)
% %Quadrant1_median = imcrop(Figure1_median, [7 1 5 5])
% %Quadrant1_median == Figure1_median(1:1:6,1:1:6); % CE N'EST PAS LA M�ME CHOSE ! (majorit� point  sont diff�rent).
% 
% %Gr�ce � cet exercice, j'ai put trouver une erreur d� � ma m�thode
% %d'obtenir la m�diane. Maitenant j'obtient le m�me r�sultat.
% %disp(image_final == Figure1_median);
%-----------------------------------------------
% 2: APPLIQUER LE FILTRE DE LA MOYENNE
% largeur_filtre = 3;
% size_filtre = [largeur_filtre, largeur_filtre];
% choix_bordure = 1; %1) 0-padding: Si sort bordure, alors valeur � l'ext�rieur � 0. 2) Wrap-around.
% 
% filtre = ones(largeur_filtre); %Trouv� via site Matlab + code de "fspecial" -> Moyenne non-pond�r�.
% filtre = (1./sum(sum(filtre))).*filtre;
% is_convolution = 1; % 1 = convolution, 2 = correlation.
% choix_bordure = 1; % 1 = 0-padding, 2 = wrap-around.
% 
% %Note Importante: Mettre en commentaire "image_calcul = im2uint8(image_calcul);" avant de l'utiliser.
% [image_calcul] = Apply_filtrer(zone_image, filtre, is_convolution, choix_bordure);
% image_calcul(1:1:6,1:1:6)
% 
% %Version Matlab (corrig� + modification pour �tre au m�me niveau)
% filtre_moy = fspecial('average');
% Figure1_moyenneur = filter2(filtre_moy, zone_image);
% Figure1_moyenneur(1:1:6,1:1:6)
% %Quadrant1_moyenneur = imcrop(Figure1_moyenneur, [7 1 5 5]); % CE N'EST PAS LA M�ME CHOSE ! (majorit� point  sont diff�rent).
% %Quadrant1_moyenneur_arrondi = floor(Quadrant1_moyenneur); % prof: arrondir le r�sultat � la partie enti�re seulement 
% 
% %R�SULTAT: M�me r�sultat final - tout est parfait !
% %disp(round(Figure1_moyenneur) == round(image_calcul));
%--------------------------------------------------




