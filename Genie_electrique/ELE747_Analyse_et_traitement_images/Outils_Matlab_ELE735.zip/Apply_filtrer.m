%% Apply_filtrer
%{
Titre: Apply_filtrer
Cours: ELE747 - session Automne 2017
Par: Vincent Rougeau-Moss

Description:
    Fonction qui applique le filtre sur l'image en utilisant la m�thode choisie pour
    les bordures. Puisque le calcule n'est pas directement addionn�/ajout�
    � l'image originale, on peut ensuite effectu� d'autre calculs avant de
    faire �a.

    Faire cet op�ration �quivaut � faire une convolution entre l'image et
    le filtre: conv2(image,filtre,'same');

Note sur les caract�ristiques n�cessaire aux calculs:
    1) Le filtre doit avoir des dimensions impair selon les 3 dimensions
       (car on a pas encore vue le cas o� filtre � dimension pair).
    2) Le filtre doit avoir des dimensions <= � l'image (logique).
    3) La fonction ne peut �tre utilis� que si on a r�ussi � exprimer le
       filtre sous la forme d'une matrice pouvant �tre appliqu� sur
       l'image.

Note sur les diff�rentes m�thode possibles:
    La m�thode du "wrap-around" est celle pr�conis� par la prof et le
    manuel (rendu au chap 4, vers section 4.7 ou 4.8 - � v�rifier). La
    m�thode "0-padding" ou de faire une continuiter des valeurs font
    causer des changements de valeurs avec des valeurs qui n'existe pas =
    zone de haute ou basse fr�quence (beaucoup ou faible contraste). Or, la
    d�riv� est un filtre passe-haut, ce qui va donc causer des changements
    pas n�cessairement attendu avec des valeurs invent�s. De plus, selon
    principe du chap 4 + prof, l'image est p�riodique = peut faire
    wrap-around sans invent� de valeur.

Note:
    Les fonctions qui lui appartenait de mani�re priv�:
    "Calculate_1_pixel_image" et "Get_value_image_bordures" ont �t� s�par�
    dans des fichiers propres � eux suite aux besoins de cr�er d'autres
    fonctions qui avaient besoins de les utiliser. Ainsi, au lieu de
    dupliquer les fonctions = probl�me � corrig� � multiple endroit par la
    suite, j'ai tout simplement mit ses fonctions � part pour que toutes
    les fonctions puissent les utiliser au besoin.

Param�tres:
    - image = image local ou global (de taille >= au filtre) sur lequel on
              se base pour appliquer le filtre sur l'image.

    - filtre = le filtre � appliquer sur l'image, soit une matrice
              (g�n�ralement, jusqu'� mainteant, de dimension impair et
              carr�) avec lequel on va effectu� le calcul.

    - is_convolution:
        1) C'est une convolution
        0) C'est une correlation.

    - choix_bordure: no de la m�thode utilis� lors de l'application du
                     filtre sur les bordures de l'image.
        1) 0-padding: Si sort bordure, alors valeur � l'ext�rieur � 0.
        2) wrap-around: (celle du prof) si � l'ext�rieur, va le cherche sur
                        l'autre cot� via modulo sur la dimension.
    
--------------------------------------------------------------------
%}
function [image_calcul] = Apply_filtrer(image, filtre, is_convolution, choix_bordure)
    [nb_line_image, nb_column_image, dim_image] = size(image);
    [nb_line_filtre, nb_column_filtre, dim_filtre] = size(filtre);
    
    image = im2double(image); %Mettre en double pour �viter probl�me d� au format "uint8t" ou autre simialaire. 
    image_calcul = image;
    %------------------------------------
    %V�rification des param�tres:
    if(nb_line_filtre > nb_line_image || nb_column_filtre > nb_column_image || dim_filtre > dim_image)
       disp('Error: Image is to much small for the filtrer');
       return;
    elseif( is_convolution ~= 0 && is_convolution ~= 1)
        disp('Error: is_convolution = 1 for Covonlution and 0 for Correlation');
        return
    elseif( choix_bordure < 1 || choix_bordure > 2)
        disp('Error: choix_bordure choice are 1 or 2');
        return;
    elseif( mod(nb_line_filtre,2) == 0 || mod(nb_column_filtre,2) == 0 || mod(dim_filtre,2) == 0)
       disp('Error: Code not adapted for case filtrer have dimension not odd (impair)');
       return;
    end
    
    %------------------------------------
    %D�but du programme:
    size_image = size(image);
    
    if(numel(size_image) == 2)
        size_image = [size_image, 1];
    end
    
    a = (nb_line_filtre-1)/2;
    b = (nb_column_filtre-1)/2;
    
    for i=1:nb_line_image
        for j=1:nb_column_image
            for k=1:dim_image
                image_calcul(i,j,k) = Calculate_1_pixel_image(image, filtre, size_image, a, b, i,j,k, is_convolution, choix_bordure);
            end%fin loop dim image
        end
    end
    
    %Reconversion de l'image - va supposer pour l'instant qu'est toujours
    %en unint8.
    image_calcul = im2uint8(image_calcul);
end

%% Calculate_1_pixel
% Description:
%   Fait le calcul de la corr�lation ou de la convolution pour 1 pixel de
%   l'image, soit l'application des �quations 3.4-3 et 3.4-4 (p.148-149)
%   sur 1 pixel de l'image. On doit ensuite r�p�ter cette op�ration sur
%   tout les pixels de l'image.
%
%   On va assumer pour l'instant qu'on est en noir et blanc = pas de 3�me
%   dimensions. Malgr� tout, en pr�vision futur, les variables pour �a font
%   rester l�.
%
%   On assume ici que filtre � dimension impair et filtre pas en couleur.
%
%Param�tres:
%   - image = l'image original au complet o� doit appliquer le filtre.
%   - filtre = matrice (aux dimension impair) avec lequel on modifie
%              l'image.
%   - a,b = (voir p.148, section 3.4.1) o� a = (m-1)/2 et b = (n-1)/2 pour
%            un filtre aux dimensions impair m x n.
%   - i,j,k = position du pixel central de l'image autour duquel applique
%             le filtre en se servant des valeurs d'intensit� de ces
%             voisins.
%   - is_convolution = 1 pour convolution, 0 pour corr�lation.
%   - choix_bordure = m�thode pour le cas des bordures (voir
%                     "Get_value_image_bordures.m"
%
%------------------------------------------------------
function [somme] = Calculate_1_pixel_image(image, filtre, size_image, a, b, i,j,k, is_convolution,choix_bordure)
    somme = 0;
    decalage_ligne = a + 1; %D�calage n�cesaire d� � d�but matrice � (1,1) - si d�bute � (0,0), enlever le "+1".
    decalage_colonne = b + 1;
    switch(is_convolution)
        case 1 % Convolution. 
            for s=-a:a
                for t=-b:b
                    tempo = Get_value_image_bordures(image, size_image(1), size_image(2), size_image(3), i-s, j-t, k, choix_bordure);
                    somme = somme + filtre(s+decalage_ligne,t+decalage_colonne).*tempo;
                end
            end
            
        case 0 %Corr�lation
            for s=-a:a
                for t=-b:b
                    tempo = Get_value_image_bordures(image, size_image(1), size_image(2), size_image(3), i+s, j+t, k, choix_bordure);
                    somme = somme + filtre(s+decalage_ligne,t+decalage_colonne).*tempo;
                end
            end
    end
end