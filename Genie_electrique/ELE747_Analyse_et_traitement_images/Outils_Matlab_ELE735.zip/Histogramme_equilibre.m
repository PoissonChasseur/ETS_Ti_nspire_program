%% Histogramme_equilibre
%{
Titre: Histogramme equilibr�
Cours: ELE747: Imagerie et traitement d'image
Par: Vincent Rougeau-Moss

Description Histogramme �quilibr�:
    L'Histrogramme �quilibr� (manuel chap 3: section 3.3: p. 120 � 144) a
    pour objectif d'�quilibr� les valeurs des couleurs sur l'intervalle de
    valeur possibles (ex. sur 8 bits = 0 � 255 = 256 valeurs) afin d'avoir
    approximativement un nombre de pixel �gal pour toutes les valeurs
    possibles d'intensit�.

    Une fonction dans le Tool box de Matlab sur l'imagerie
    [himhist(image)], mais je voulais aussi m'y essayer afin de facilit�
    son impl�mentation dans la Ti nspire cx cas, car c'est un no d'exercice
    et car on l'a aussi fait en classe.

    Puisque j'ai le Tools box d'imagerie de Matlab, je vais donc me
    permettre d'utiliser ces fonctionnalit�s aux besoins (ex utilis�
    l'outils de Matlab plut�t que ce code, car Matlab plus fiable que moi).

Description fonction:
    Fonction qui affiche et envoie la matrice de l'histogramme o� 1�re
    colonne = les valeurs d'intensit� initiale et 2�me colonne = les 
    valeurs finale obtenue apr�s transformations.

    On va essayer de prendre le moins de fonction d�j� faite dans Matlab
    que possible pour aider � la programmation de la Ti nspire cx cas qui
    n'a pas acc�es � �a.
 
    L'image doit �tre en noir et blanc et avoir d�j� �t� obtenue sous forme
    matricielle (voir code plus bas comme exemple).

Param�tres:
    - La matrice de l'image obtenue via: imread('nom_image.type_image').
    - Note: L'image doit �tre en noir et blanc (pas en couleur).

Note:
    Cet algo fonctionne plut�t bien, mais est moins performant que "histeq"
    qui donne un histogramme vraiment mieux �quilibr�. Cependant, le plus
    important est surtout d'avoir un algo comme celui vue en classe pour
    pouvoir le reproduire � l'examen plus rapidement.

Note: 
    � v�rifier l'algo avec un exercice et l'algo programm� correspond
    exactement � la m�me m�thodologie et on obtient les m�mes r�sultats que
    ce que la prof nous � pr�senter en classe = parfait.

Fonction Matlab �quilvalente - code prit en note du code de la prof:
    1) f = imread('non_image.tif'); %Obtenir l'image avec degr� de couleur.
    2) imagesc(f) %Affiche l'image
    3) colormap('gray'); %Mettre l'image en noir et blanc
    4) figure(2) %Cr�er figure #2
    5) imhist(f) %histogramme de l'image original
    ----------------------
    6) g = histeq(f); %Obtenir image apr�s passage Algo de l'histogramme
    �quilibr�
    7) figure(3)
    8) imagesc(g) %Afficher l'image obtenue vie histogramme �quilibr�
    9) colormap('gray');
    10) figure(4)
    11) imhist(g) %Afficher l'historgramme �quilibr� final
    
--------------------------------------------------------------------
%}
function [histogramme, image_final] = Histogramme_equilibre(image)
    clc;
    
    %�TAPE #1: L'initialisation:
    [nb_row, nb_column, dim] = size(image); %3eme dimension seulement si en couleur.
    nb_pixels = nb_row*nb_column*dim; %Pour avoir le nb total de pixel dans l'image.
    
    nb_possible_value = double(max(max(image))); %2^nb_bits_for_image-1 %Cette new m�thode est plus g�n�rale.
    
    %-----------------------------------
    %�TAPE #2: Obtenir le nb occurence de toutes les valeurs d'intensit� possibles.
    [matrix_occurence, nb_ligne_matrix] = Count_nb_occurence(image);
    %matrix_occurence %Afficher la matrice d'occurence pour la v�rifier.
    
    %-----------------------------------
    %�TAPE #3: Mettre le nb occurence en % sur le total + obtenir le % cumul� des valeurs.
    histogramme = zeros(nb_ligne_matrix,4);
    histogramme(:,1) = double(matrix_occurence(:,1));
    histogramme(:,2) =  double(matrix_occurence(:,2))./nb_pixels;
    
    histogramme(1,3) = histogramme(1,2);
    for i=2:nb_ligne_matrix
        histogramme(i,3) =  histogramme(i-1,3) + histogramme(i,2);
    end
    %-----------------------------------
    %�TAPE #4: Multiplier les % cumul� par le nb valeur possible et arrondir ces
    %valeur � l'entier le plus proche (manuel arrondi 0.5 � 1, Matlab  = pareille).
    %Les r�sultats obtenues = les nouvelles valeurs des pixels � utiliser.
    histogramme(:,4) = round(histogramme(:,3).*nb_possible_value);
    
    %-----------------------------------
    %�TAPE #5: Remplacer les valeurs des pixels de l'image par les nouvelles valeurs.
    image_final = image;
    for i=1:nb_row
        for j=1:nb_column
            column = double(image(i,j,1)) + 1; %Si met pas en double, il n'incr�mente pas.
            image_final(i,j,1) = uint8(histogramme(column,4));
        end
    end
    
    
end

%% Count_nb_occurence
%Description:
%   Fonction obtenir une matrice donnant le nb occurence de chaque valeur
%   de la matrice. Pr�f�rablement, devrait �tre uniquement utiliser pour
%   matrice ayant des nombres entiers (ou nb entier mit en flottant, mais
%   le moins de d�cimale que possible, car infinie valeur possible si
%   flottant, en th�orie).
%
%   M�thode assez simple et efficace qui corrige le probl�me de commencer �
%   1 au lieu de 0 les no de ligne et colonne.
%
%Fonction Matlab �quivalent:
%   histc -> � v�rifier.
%-------------------
function [matrix_occurence, nb_ligne_matrix] = Count_nb_occurence(image)
    [nb_row, nb_column, ~] = size(image); %3eme dimension seulement si en couleur.
    nb_possible_value = double(max(max(image))); %Cette m�thode est plus s�r que le nb bit (qui peut �tre inconnue en plus).
    %nb_possible_value = 2^nb_bits_for_image-1;
    
    matrix_occurence = zeros(nb_possible_value+1, 2); %Nb ligne + 1, car commence � 1 et non � 0.
    nb_ligne_matrix = nb_possible_value+1;
    
    %�criture de la 1�re colonne.
    for actual_value=0:nb_possible_value
       matrix_occurence(actual_value+1,1) = actual_value; 
    end

    %�criture de la 2�me colonne.
    for i=1:nb_row
        for j=1:nb_column
            actual_value = image(i,j,1);
            
%             if(actual_value == 255) %Pour le d�bogage.
%                disp('VINCENT !'); 
%             end
%             fprintf('i = %d, j = %d, actual_value = %d\n',i,j,actual_value);
            
            column = double(actual_value) + 1; %Si met pas en double, il n'incr�mente pas.
            matrix_occurence(column,2) = matrix_occurence(column,2) + 1; %(+1) car si � 0, va planter.
            
        end
    end
end