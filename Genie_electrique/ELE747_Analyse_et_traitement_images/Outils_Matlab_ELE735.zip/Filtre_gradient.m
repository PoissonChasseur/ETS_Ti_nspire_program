%% Filtre_gradient
%{
Titre: Filtre_Gradient (filtre passe-haut).
Cours: ELE747 - session Automne 2017
Par: Vincent Rougeau-Moss

Description:
    Le filtre du gradient correspond � l'application d'un filtre qui est
    approximativement �quivalent � l'�quation de la d�riv� 1�re num�rique.
    Cependant, contrairement au Laplacien (d�riv� seconde) o� aucune approx
    n�cessaire (math�matiquement), des approx plus grossi�re comme
    sqrt(a^2+b^2) = abs(a)+abs(b) et division par 2 = division par 1 ont
    �t� faite par le manuel.
    Cependant, on peut appliquer seulement le gradient en x, en y ou les
    deux sur l'image, ce qui donne la possibilit� de conserver seulement
    les contours que l'on souhaite (si c'est ce qu'on veut faire).

    C'est un filtre passe-haut au m�me titre que le Laplacien, c'est � dire
    que les variations importante d'intensit� (= haute fr�quence) sont
    moins touch� que les zones de basse fr�quence o� aucune ou peu de
    variation d'intensit�.

Note de d�v�loppement:

Code Matlab �quivalent:

Param�tres:
    - image = L'image original au complet.
    - is_convolution = 1 si convolution, 0 si corr�lation.
    - choix_gradient = no entre 1 et 6: Robert_X, Robert_Y, Robert_X_Y,
                       Sobel_X, Sobel_Y, Sobel_X_Y.
    - choix_bordure = m�thode choisit pour les bordures (voir
                      Get_value_image_bordure)
--------------------------------------------------------------------
%}
function [image_calcul] = Filtre_gradient(image_complete, is_convolution, choix_gradiant, choix_bordure)
    Robert_cross_gradient_X = [-1,0; 0,1]; %Vue que pas encore vue comme appliqu� filtre � dimension pair, 
    Robert_cross_gradient_Y = [0,1; -1,0]; %on va oublier ces filtres pour le moment.
    
    Sobel_X = [-1,-2,-1; 0,0,0; 1,2,1];
    Sobel_Y = [-1,0,1; -2,0,2; -1,0,1];
    
    %----------------------------------
    %V�rification des param�tres
    if (choix_gradiant < 1 || choix_gradiant > 6)
        disp('Error: choix_gradiant is between 1 and 6');
        return;
    elseif(choix_gradiant == 1 || choix_gradiant == 2 || choix_gradiant == 3)
        disp('Sorry, Apply_filtrer is not adapted for moment for the case filtrer have dimension pair');
        disp('When the fonction will be adapted for that, you will be able to do it');
        return;
    end
    %----------------------------------
    %D�but programme sachant param�tres valides.
    
    %S�lection des filtres � utiliser.
    switch(choix_gradiant)
        case 1 % Robert_cross_gradient_X
            gradient = Robert_cross_gradient_X;
        case 2 % Robert_cross_gradient_Y
            gradient = Robert_cross_gradient_Y;
        case 3 % Robert_cross_gradient_X et Robert_cross_gradient_Y
            gradient = Robert_cross_gradient_X;
            gradient_2 = Robert_cross_gradient_Y;
        case 4 % Sobel_X
            gradient = Sobel_X;
        case 5 % Sobel_Y
            gradient = Sobel_Y;
        case 6 % Sobel_X et Sobel_Y
            gradient = Sobel_X;
            gradient_2 = Sobel_Y;
    end
    
    %Application des filtres sur l'image
    [image_calcul] = Apply_filtrer(image_complete, gradient, is_convolution, choix_bordure);
    
    if(choix_gradiant == 3 || choix_gradiant == 6) %Cas o� 2 filtres
        [image_calcul_2] = Apply_filtrer(image_complete, gradient_2, is_convolution, choix_bordure);
        
        %Conversion des 2 images en double afin d'ensuite les additioner.
        image_calcul = im2double(image_calcul);
        image_calcul_2 = im2double(image_calcul_2);
        image_calcul = image_calcul + image_calcul_2;
        image_calcul = im2uint8(image_calcul);
    end
end

