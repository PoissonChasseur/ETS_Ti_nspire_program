%% Intensity_transformation
%{
Titre: Intensity_transformation
Cours: ELE747 - session Automne 2017
Par: Vincent Rougeau-Moss

Description:
    Fonction pouvant r�alis� diff�rent changement d'intensit� pr�sent� dans
    le chap 3, section 3.2, p. 107 � 117. L'histogramme �quilibr� est
    exclue d'ici, car il a d�j� son propre fichier pour faire �a.

    N�cessite d'avoir une image inital qui peut �tre en noir et blanc ou en
    couleur. L'image envoy� peut �tre une sous-partie local de l'image
    total, ce qui donnera une modification local par rapport � l'image
    original (une fois le transfert vers image compl�te effectu�).
    
Param�tres:
    1) image = L'image ou la portion de l'image compl�te � modifier.
    
    2) max_value = la valeur maximale que peuvent avoir les pixels. Soit
    sera max(max(image)) (noir et blanc), soit sera 2^(nb_bit)-1.
    Uniquement utilis� par "Image_Negative"

    3) c et gamma: des constantes. c est utilis� par "Log" et "Power"
    transoformation. Gamma = seulement "Power transformation".
    
    3) Choix = le no de la transformations � utiliser.
        1) Image n�gative (inverse les couleurs).
        2) Transformation logarithmique.
        3) Transformation 

--------------------------------------------------------------------
%}
function [image_final] = Intensity_transformation(image, max_value, c, gamma, choix)
    image_final = image;
    
    %V�rification des param�tres:
    if(choix == 1 && (isempty(max_value) || max_value <= 0))
        disp('Error: max_value important for Image_Negative and max_value > 0');
        return;
    elseif(isempty(c) && (choix==2 || choix == 3))
        disp('Error: c is important for Log and Power transformation');
        return;
    elseif(isempty(gamma) && choix == 3)
        disp('Error: gamma is important for Power transformation');
        return;
    end
    %---------------------
    %D�but du programme:
    
    switch(choix)
        case 1 % Image_Negative.
            [image_final] = Image_Negative(image, max_value);
            
        case 2 % Log_Transformation
            [image_final] = Log_Transformation(image, c);
            
        case 3 % Power_law_Transformation (Gamma transformation/correction)
            [image_final] = Power_law_Transformation(image, c, gamma);
    end

end

%% Image_Negative
%Description:
%   Inverse les couleurs de l'image via: 
%       Valeur_Pixel = Valeur_Max - Valeur_Pixel
%
%Param�tres:
%   - Image = L'image original (sur lequel on se base pour la modifi�).   
%   - Max_value = la valeur maximale qu'on tous les pixels (modifier le
%   code si pas le cas).
%
%------------------------------------------
function [image_final] = Image_Negative(image, max_value)
    image_final =  max_value - image;
end

%% Log_Transformation
%Description:
%   Effectue une op�ration Logarithmique sur les valeurs de la matrice, ce
%   qui est notamment tr�s utile pour Fourrier o� valeur peuvent �tre
%   sup�rieur � la valeur max affichage (ex. du manuel: valeur de 0 �
%   1.5*10^6 -> 0 � 6.2 via c = 1.). �quation effectu�:
%       Pixel = c*log(1 + Pixel).
%
%Param�tres:
%   - Image = L'image original (sur lequel on se base pour la modifi�). 
%   - c = la constante qui multiplie l'�quation.
%------------------------------------------
function [image_final] = Log_Transformation(image, c)
    image_final = im2double(image);
    image_final = c*log(1 + image_final);
    image_final = im2uint8(image_final);
end

%% Power_law_Transformation (Gamma Transformation/correction)
%Description:
%   Effectue une op�ration d'exposant (pow en C et C++) afin de modifier
%   les valeurs des pixels de l'image. Peut donner des r�sultats similaire
%   � log, mais est plus flexible via plus de param�tres. On peut donc s'en
%   servir pour augmenter ou r�duire les valeurs et ainsi, r�duire ou
%   augmenter la gamme de valeur d'intensit� utilis� par l'image.
%
%   �quation effectu�:
%       Pixel = c *(pixel^gamma)
%
%   On l'appelle "Power law" ou "Gamma" transformation/correction.
%
%Param�tres:
%   - Image = L'image original (sur lequel on se base pour la modifi�).
%   - c = la cte qui multiplie
%   - gamma = la valeur de l'exposant.
%------------------------------------------
function [image_final] = Power_law_Transformation(image, c, gamma)
    image_final = im2double(image);
    image_final = c*(image_final.^gamma);
    image_final = im2uint8(image_final);
end
